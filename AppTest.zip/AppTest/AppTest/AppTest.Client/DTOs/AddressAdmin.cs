﻿namespace AppTest.Client.DTOs
{
    public sealed class AddressAdmin
    {
        public string Reference { get; set; } = string.Empty;
        public string PlaceName { get; set; } = string.Empty;
        public string District { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
