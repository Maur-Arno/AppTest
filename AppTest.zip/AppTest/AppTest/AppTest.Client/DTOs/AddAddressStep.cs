﻿namespace AppTest.Client.DTOs
{
    public enum AddAddressStep
    {
        Information,
        CheckingDuplicate,
        DuplicateFound,
        Confirmation
    }
}
