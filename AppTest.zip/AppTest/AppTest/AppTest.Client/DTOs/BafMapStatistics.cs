﻿namespace AppTest.Client.DTOs
{
    public sealed class BafMapStatistics
    {
        public int CitiesCount { get; set; }
        public int QuartersCount { get; set; }
        public int LocationsCount { get; set; }
    }
}
