﻿namespace AppTest.Client.DTOs
{
    /// <summary>
    /// Point de localisation.
    /// </summary>
    public sealed class LocationPosition
    {
        public double Latitude { get; init; }
        public double Longitude { get; init; }
        public double? Precision { get; init; }
        public DateTime CapturedAt { get; init; } = DateTime.UtcNow;
    }
}
