﻿namespace AppTest.Client.DTOs
{
    public sealed class LocationPosition
    {
        public double Latitude { get; init; }
        public double Longitude { get; init; }
        public double Precision { get; init; }
    }
}
