﻿namespace AppTest.Client.DTOs
{
    public enum RequestStatus
    {
        None,
        Pending,
        Validated,
        Rejected,
        Merged
    }
}
