﻿namespace AppTest.Client.DTOs
{
    public sealed class AddressRequest
    {
        public string Reference { get; set; } = string.Empty;
        public string PlaceName { get; set; } = string.Empty;
        public double DistanceMeters { get; set; }
        public double Latitude { get; set; }
        public double Longitude { get; set; }
        public double GpsAccuracy { get; set; }
    }
}
