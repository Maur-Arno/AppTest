﻿namespace AppTest.Client.DTOs
{
    public sealed class AddressDto
    {
        public string Reference { get; set; } = string.Empty;

        public string Name { get; set; } = null!;

        public string District { get; set; } = null!;

        public string Category { get; set; } = string.Empty;

        public double? Latitude { get; set; }

        public double? Longitude { get; set; }

        public double? GpsAccuracy { get; set; }

        public string PlusCode { get; set; } = string.Empty;

        public string? PhotoUrl { get; set; }
    }
}
