﻿namespace AppTest.Client.DTOs
{
    public sealed class AddressDto
    {
        public string Name { get; set; } = string.Empty;

        public string Reference { get; set; } = string.Empty;

        public string District { get; set; } = string.Empty;

        public string PlusCode { get; set; } = string.Empty;

        public double Latitude { get; set; }

        public double Longitude { get; set; }

        public string? PhotoUrl { get; set; }
    }
}
