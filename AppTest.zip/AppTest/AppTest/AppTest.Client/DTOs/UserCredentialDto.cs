﻿namespace AppTest.Client.DTOs
{
    public record UserCredentialDto(
        string UserName,
        string Token,
        DateTime? Expires
        );
}
