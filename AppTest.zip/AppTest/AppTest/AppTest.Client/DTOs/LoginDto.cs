﻿namespace AppTest.Client.DTOs
{
    public record LoginDto(
        string PhoneNumber,
        string Password);
}
