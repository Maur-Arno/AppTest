﻿namespace AppTest.Client.DTOs
{
    public sealed class DashboardStatistics
    {
        public int TotalPlaces { get; set; }

        public int TotalRequests { get; set; }

        public int PendingRequests { get; set; }
    }
}
