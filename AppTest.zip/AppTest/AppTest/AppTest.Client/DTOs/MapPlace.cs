﻿namespace AppTest.Client.DTOs
{
    public sealed class MapPlace
    {
        public long Id { get; init; }
        public string Reference { get; init; } = string.Empty;
        public string Name { get; init; } = string.Empty;
        public string Category { get; init; } = string.Empty;
        public string District { get; init; } = string.Empty;
        public double Latitude { get; init; }
        public double Longitude { get; init; }
    }
}
