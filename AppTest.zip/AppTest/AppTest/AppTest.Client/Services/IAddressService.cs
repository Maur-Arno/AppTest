﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public interface IAddressService
    {
        /// <summary>
        /// Récupère l'adresse via sa référence
        /// </summary>
        /// <param name="reference">Référence du lieux</param>
        /// <returns>Address</returns>
        Task<AddressDto?> GetByReferenceAsync(string reference);

        /// <summary>
        /// Recherche les lieux officiels existants autour d'une position donnée.
        /// </summary>
        /// <param name="selectedPosition">position sélectionnée</param>
        /// <param name="radiusMeters">précision (en mètres)</param>
        /// <returns>List<AddressDto></returns>
        Task<bool> FindOfficialNearByPlacesAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default);

        /// <summary>
        /// Récupère le lieux officiel existant autour d'une position donnée.
        /// </summary>
        /// <param name="selectedPosition">position sélectionnée</param>
        /// <param name="radiusMeters">précision (en mètres)</param>
        /// <returns>List<AddressDto></returns>
        Task<AddressDto> GetOfficialNearByPlaceAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default);

        /// <summary>
        /// Crée une adresse en attente de validation par la mairie.
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        Task<bool> CreateLocationRequestAsync(AddressDto address);

        /// <summary>
        /// Recherche les demandes d'adressage à valider.
        /// </summary>
        /// <param name="city">ville/localité concernée</param>
        /// <param name="month">mois de récupération</param>
        /// <param name="year">annéé de récupération</param>
        /// <returns>True/False</returns>
        Task<bool> FindPendindLocations(string city, int month, int year, CancellationToken cancellationToken = default);

        /// <summary>
        /// Récupère les demandes d'adressage à valider par l'agent municipal.
        /// </summary>
        /// <param name="city">ville/localité concernée</param>
        /// <param name="month">mois de récupération</param>
        /// <param name="year">AddressDto de récupération</param>
        /// <returns>List<AddressDto></returns>
        Task<List<AddressDto>> GetPendindLocations(string city, int month, int year, CancellationToken cancellationToken = default); 
    }
}
