﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public interface IAddressService
    {
        /// <summary>
        /// Récupérer l'adresse via sa référence
        /// </summary>
        /// <param name="reference">Référence du lieux</param>
        /// <returns>Address</returns>
        Task<AddressDto?> GetByReferenceAsync(string reference);
    }
}
