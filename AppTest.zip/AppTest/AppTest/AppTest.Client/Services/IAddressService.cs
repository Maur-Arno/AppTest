﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public interface IAddressService
    {
        /// <summary>
        /// Récupérer l'adresse via sa référence
        /// </summary>
        /// <param name="reference">Référence du lieux</param>
        /// <returns>Address</returns>
        Task<AddressDto?> GetByReferenceAsync(string reference);

        /// <summary>
        /// Récupérer les lieux officiels existants autour d'une position donnée.
        /// </summary>
        /// <param name="selectedPosition">position sélectionnée</param>
        /// <param name="radiusMeters">précision (en mètres)</param>
        /// <returns>List<AddressDto></returns>
        Task<List<AddressDto>?> FindOfficialNearByPlacesAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default);

        /// <summary>
        /// Crée une adresse en attente de validation par la mairie.
        /// </summary>
        /// <param name="address"></param>
        /// <returns></returns>
        Task<bool> CreateLocationRequestAsync(AddressDto address);
    }
}
