﻿using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.IdentityModel.JsonWebTokens;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace AppTest.Client.Services
{
    public class TokenAuthenticationStateProvider(HttpClient httpClient) : AuthenticationStateProvider
    {
        private readonly HttpClient http = httpClient;
        private string? SavedToken;

        // determine the current users authentication state
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            if (SavedToken != null)
            {
                var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(SavedToken);
                if (DateTime.UtcNow >= claimObject.ValidTo)
                {
                    MarkUserAsLoggedOut();
                    return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
                }

                http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", SavedToken);
                var authenticatedUser = new ClaimsPrincipal(new ClaimsIdentity(claimObject.Claims, "serverauth"));
                return await Task.FromResult(new AuthenticationState(authenticatedUser));
            }

            return await Task.FromResult(new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity())));
        }

        public void MarkUserAsAuthenticated(string token)
        {
            SavedToken = token;
            var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(token);
            var authenticatedUser = new ClaimsPrincipal(new ClaimsIdentity(claimObject.Claims, "serverauth"));
            var authState = Task.FromResult(new AuthenticationState(authenticatedUser));
            http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", SavedToken);
            NotifyAuthenticationStateChanged(authState);
        }

        public void MarkUserAsLoggedOut()
        {
            SavedToken = null;
            var anonymousUser = new ClaimsPrincipal(new ClaimsIdentity());
            var authState = Task.FromResult(new AuthenticationState(anonymousUser));
            http.DefaultRequestHeaders.Authorization = null;
            NotifyAuthenticationStateChanged(authState);
        }

        public string GetAuthenticatedUserData(string claimType)
        {
            var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(SavedToken);
            return claimObject.Claims.FirstOrDefault(x => x.Type == claimType)!.Value;
        }
    }
}
