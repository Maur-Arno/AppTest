﻿using AppTest.Client.DTOs;
using Microsoft.AspNetCore.Components.Authorization;
using System.Net.Http.Json;
using System.Text.Json;

namespace AppTest.Client.Services
{
    public class AuthService(HttpClient httpClient, AuthenticationStateProvider authenticationStateProvider) : IAuthService
    {
        private readonly HttpClient _httpClient = httpClient;
        private readonly AuthenticationStateProvider _authenticationStateProvider = authenticationStateProvider;

        public async Task<string> LoginAsync(LoginDto login)
        {
            var response = await _httpClient.PostAsJsonAsync("api/auth/login", login);

            if (response.IsSuccessStatusCode)
            {
                var loginResult = await response.Content.ReadFromJsonAsync<UserCredentialDto>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

                ((TokenAuthenticationStateProvider)_authenticationStateProvider).MarkUserAsAuthenticated(loginResult?.Token!);

                return loginResult?.UserName!;
            }

            return string.Empty;
        }

        public void Logout() => ((TokenAuthenticationStateProvider)_authenticationStateProvider).MarkUserAsLoggedOut();
    }
}
