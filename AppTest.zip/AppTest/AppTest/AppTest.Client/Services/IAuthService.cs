﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public interface IAuthService
    {
        Task<string> LoginAsync(LoginDto login);
        void Logout();
    }
}
