﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public class AddressService : IAddressService
    {
        public async Task<AddressDto?> GetByReferenceAsync(string reference)
        {
            var normalizedReference = reference.Trim().ToUpperInvariant();

            if (normalizedReference == "BAF-DJE-C-000125")
            {
                return new AddressDto
                {
                    Reference = "BAF-DJE-C-000125",
                    Name = "Restaurant La Paix",
                    District = "Djeleng",
                    Latitude = 5.473921,
                    Longitude = 10.417832
                };
            }

            return null;
        }

        public async Task<bool> FindOfficialNearByPlacesAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default)
        {
            return true;
        }

        public async Task<AddressDto> GetOfficialNearByPlaceAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default)
        {
            return new AddressDto
            {
                Reference = "BAF-DJE-C-000125",
                Name = "Restaurant La Paix",
                District = "Djeleng",
                Latitude = 5.473921,
                Longitude = 10.417832
            };
        }

        public async Task<bool> CreateLocationRequestAsync(AddressDto address)
        {
            return true;
        }

        public async Task<bool> FindPendindLocations(string city, int month, int year, CancellationToken cancellationToken = default)
        {
            return true;
        }

        public async Task<List<AddressDto>> GetPendindLocations(string city, int month, int year, CancellationToken cancellationToken = default)
        {
            return new List<AddressDto>
            {
                new AddressDto
                {
                    Reference = "BAF-DJE-C-000125",
                    Name = "Restaurant La Paix",
                    Category = "Restaurant",
                    District = "Djeleng",
                    Latitude = 5.473921,
                    Longitude = 10.417832
                },

                new AddressDto
                {
                    Reference = "BAF-KAM-C-000126",
                    Name = "Boutique Mboa",
                    Category = "Boutique",
                    District = "Kamkop",
                    Latitude = 5.475200,
                    Longitude = 10.419100
                },

                new AddressDto
                {
                    Reference = "BAF-DJE-C-000127",
                    Name = "Pharmacie Djeleng",
                    Category = "Pharmacie",
                    District = "Djeleng",
                    Latitude = 5.472600,
                    Longitude = 10.415800
                },

                new AddressDto
                {
                    Reference = "BAF-KAM-C-000128",
                    Name = "Hôtel Mboa",
                    Category = "Hôtel",
                    District = "Kamkop",
                    Latitude = 5.476200,
                    Longitude = 10.421000
                }
            };
        }
    }
}
