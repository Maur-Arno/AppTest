﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public class AddressService : IAddressService
    {
        public async Task<AddressDto?> GetByReferenceAsync(string reference)
        {
            var normalizedReference = reference.Trim().ToUpperInvariant();

            if (normalizedReference == "BAF-DJE-C-000125")
            {
                return new AddressDto
                {
                    Reference = "BAF-DJE-C-000125",
                    Name = "Restaurant La Paix",
                    District = "Djeleng",
                    Latitude = 5.473921,
                    Longitude = 10.417832
                };
            }

            return null;
        }

        public async Task<List<AddressDto>?> FindOfficialNearByPlacesAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default)
        {
            return null;
        }

        public async Task<bool> CreateLocationRequestAsync(AddressDto address)
        {
            return true;
        }
    }
}
