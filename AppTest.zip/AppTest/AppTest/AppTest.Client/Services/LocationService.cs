﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public class LocationService : ILocationService
    {
        public async Task<object> FindNearByPlaceAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default)
        {
            await Task.CompletedTask;
            return null!;
        }
    }
}
