﻿using AppTest.Client.DTOs;

namespace AppTest.Client.Services
{
    public interface ILocationService
    {
        /// <summary>
        /// Récupérer le lieux existant autour du point sélectionné
        /// </summary>
        /// <param name="position">Position sélectionnée</param>
        /// <param name="radiusMeters">Précision en mètres</param>
        /// <returns>NearByPlaceResult</returns>
        Task<object> FindNearByPlaceAsync(LocationPosition selectedPosition, double radiusMeters, CancellationToken cancellationToken = default);
    }
}
