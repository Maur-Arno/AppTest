﻿namespace AppTest.Client
{
    public static class ConstantPositions
    {
        public const double CUBafLat = 5.472454;
        public const double CUBafLong = 10.419137;
        public const double CUYdeLat = 5.472454;
        public const double CUYdeLong = 10.419137;
        public const double CUDlaLat = 5.472454;
        public const double CUDlaLong = 10.419137;
    }
}
