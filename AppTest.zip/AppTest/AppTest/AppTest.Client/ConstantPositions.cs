﻿namespace AppTest.Client
{
    public static class ConstantPositions
    {
        public const double DuplicateRadiusMeters = 10;
        public const double CUBafLat = 5.472454;
        public const double CUBafLong = 10.419137;
        public const double CUBerLat = 4.55265;
        public const double CUBerLong = 13.634654;
        public const double CUNkoLat = 4.956841;
        public const double CUNkoLong = 9.93605;
        public const double CUNgaLat = 7.317637;
        public const double CUNgaLong = 13.577470;
        public const double CUYdeLat = 5.472454;
        public const double CUYdeLong = 10.419137;
        public const double CUDlaLat = 5.472454;
        public const double CUDlaLong = 10.419137;
    }
}
