using AppTest.Client.Services;
using Microsoft.AspNetCore.Components.WebAssembly.Hosting;

var builder = WebAssemblyHostBuilder.CreateDefault(args);

builder.Services.AddScoped<IAddressService, AddressService>();
builder.Services.AddScoped<ILocationService, LocationService>();

await builder.Build().RunAsync();
