using AKSoftware.Localization.MultiLanguages;
using AppTest.Client.DTOs;
using AppTest.Client.Services;
using AppTest.Components;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Services.AddOptions();
//builder.Services.AddInfrastructureDI(builder.Configuration.GetConnectionString("BafMapDbConnection"));
//builder.Services.AddNeedsDI();
builder.Services.AddDistributedMemoryCache(); // Pour stocker les Sessions.
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddCookie(options =>
    {
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    })
    .AddJwtBearer(options =>
    {
        options.SaveToken = true;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new TokenValidationParameters()
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:key"]!))
        };
    });
builder.Services.AddAuthorization();

// configure Asp.Net Core Identity cookies
builder.Services.ConfigureApplicationCookie(option =>
{
    option.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    option.Cookie.SameSite = SameSiteMode.Lax;
    option.ExpireTimeSpan = TimeSpan.FromHours(2);
    option.Cookie.HttpOnly = true;
    option.SlidingExpiration = true;
    option.Events.OnRedirectToLogin = context =>
    {
        if (context.Request.Path.StartsWithSegments("/api"))
        {
            context.Response.StatusCode = 401;
            return Task.CompletedTask;
        }
        context.Response.Redirect(context.RedirectUri);
        return Task.CompletedTask;
    };
});

// Configur tous les cookies (essentiels: auth, session) par d�faut
builder.Services.Configure<CookiePolicyOptions>(option =>
{
    option.CheckConsentNeeded = _ => true;
    option.MinimumSameSitePolicy = SameSiteMode.Lax;
    option.Secure = CookieSecurePolicy.Always;
    option.OnAppendCookie = context =>
    {
        context.CookieOptions.HttpOnly = true;
        context.CookieOptions.SameSite = SameSiteMode.Lax;
    };
});

// Controle tous les tokens g�n�r�s pour les email/phonenumber confirmation, password reset, two-fator...
builder.Services.Configure<DataProtectionTokenProviderOptions>(o =>
    o.TokenLifespan = TimeSpan.FromHours(3)); // changes all data protection tokens timeout period to 3 hours.

// prot�ge contr l'attaque force-brute.
builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
    {
        var key = httpContext.User.Identity?.Name ?? httpContext.Connection.RemoteIpAddress?.ToString() ?? "anonymous";
        return RateLimitPartition.GetFixedWindowLimiter(key, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 100,
            Window = TimeSpan.FromMinutes(1),
            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
            QueueLimit = 2
        });
    });
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
});

builder.Services.AddHealthChecks();

// Compresser les r�ponses seveur -> client pour une meilleure latence.
builder.Services.AddResponseCompression(options =>
{
    options.Providers.Add<BrotliCompressionProvider>();
    options.Providers.Add<GzipCompressionProvider>();
    options.EnableForHttps = true;
    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(["application/octet-stream", "image/svg+xml"]);
});

// Lutter contre les attaques CSRF !
builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "X-CSRF-TOKEN";
    options.Cookie.Name = "X-CSRF-COOKIE";
});

builder.Services.AddMemoryCache();
builder.Services.AddLanguageContainerForBlazorServer(typeof(Program).Assembly);
builder.Services.AddScoped(sp => new HttpClient());
builder.Services.AddScoped<AuthenticationStateProvider, TokenAuthenticationStateProvider>();
builder.Services.AddScoped<IAuthService, AuthService>();
builder.Services.AddScoped<IAddressService, AddressService>();

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveWebAssemblyComponents();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
    app.UseDeveloperExceptionPage(new() { SourceCodeLineCount = 10 });
}
else
{
    // proxy / Load balancer
    app.UseForwardedHeaders(new ForwardedHeadersOptions
    {
        ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
    });

    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();
app.UseResponseCompression();
//app.UseStaticFiles(new StaticFileOptions
//{
//    FileProvider = new PhysicalFileProvider(Path.Combine(builder.Environment.ContentRootPath, "public")),
//    RequestPath = "/static"
//});
app.UseCookiePolicy();
app.UseRouting();
app.UseAuthentication();
app.UseSession();
app.UseAuthorization();
app.UseAntiforgery();
app.UseRateLimiter();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(AppTest.Client._Imports).Assembly);

app.MapGet("/api", (HttpContext httpCtxt, IAntiforgery antif) =>
{
    var tokens = antif.GetAndStoreTokens(httpCtxt);
    httpCtxt.Response.Cookies.Append(tokens?.HeaderName!, tokens?.CookieToken!);
    return Results.Ok("BafMap API (-_-)");
})
.WithName("XSRFBafMapAPI")
.WithSummary("Ins�re un jeton anti contrefa�on")
.Produces(StatusCodes.Status200OK);

var allApi = app.MapGroup("/api/auth").WithTags("Authentication");

allApi.MapPost("/login", async Task<Results<Ok<UserCredentialDto>, BadRequest<string>>> (LoginDto query, HttpContext httpCtxt) =>
{
    var role = query.PhoneNumber == "697177054" ? "MunicipalAgent" : "Citizen";
    var user = new { UserName = "PML", query.PhoneNumber, Role = role };

    var authClaims = new Dictionary<string, object>
    {
        { ClaimTypes.Name, user.UserName },
        { ClaimTypes.MobilePhone, user.PhoneNumber },
        { ClaimTypes.Role, user.Role }
    };

    var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(app.Configuration["Jwt:key"]!));

    var token = new SecurityTokenDescriptor
    {
        Issuer = app.Configuration["Jwt:Issuer"],
        Audience = app.Configuration["Jwt:Audience"],
        Expires = DateTime.Now.AddHours(1),
        Claims = authClaims,
        SigningCredentials = new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256Signature)
    };

    return await Task.FromResult(TypedResults.Ok(new UserCredentialDto(user.UserName, new JsonWebTokenHandler().CreateToken(token), token.Expires)));
})
.WithName("Login")
.Accepts<LoginDto>("application/json")
.Produces(StatusCodes.Status200OK);

allApi.MapPost("/register", async Task<Results<Created, InternalServerError>> (CreateUserCommand cmd, IMediator mediator) => await mediator.Send(cmd)
                                                                    ? TypedResults.Created()
                                                                    : TypedResults.InternalServerError())
.WithName("CreateUser")
.WithSummary("Cr�e un utilisateur")
.Accepts<CreateUserCommand>("application/json")
.Produces<CreateUserCommand>(StatusCodes.Status201Created)
.Produces(StatusCodes.Status500InternalServerError);

allApi.MapPost("/verify", async Task<Results<Ok, InternalServerError>> (ConfirmPhoneNumberCommand cmd, IMediator mediator) => await mediator.Send(cmd)
                                                                    ? TypedResults.Ok()
                                                                    : TypedResults.InternalServerError())
.WithName("VerifyUserPhoneNumber")
.WithSummary("V�rifie le num�ro de t�l�phone d'un utilisateur")
.Accepts<ConfirmPhoneNumberCommand>("application/json")
.Produces(StatusCodes.Status200OK)
.Produces(StatusCodes.Status500InternalServerError);


var profileApi = app.MapGroup("/api/users").RequireAuthorization();

profileApi.MapGet("/{number:length(9)}", async Task<Results<Ok<UserDto>, NotFound>> (string number, IMediator mediator) =>
{
    var user = await mediator.Send(new GetUserByPhoneNumberQuery(number));
    return user != null ? TypedResults.Ok(new ProfileDto(user.Id, user.NIN!, user.IdCardNumber!, user.UserName!, user.BirthDate,
                user.Address?.City!, user.Address?.StreetAddress, user.Gender!, user.PhoneNumber!, user.Nationality!, user.Occupation!, user.DateOfIssue, user.ExpirationDate, user.ProfilePicture!, user.CV!, user.LastModified, user.Version)) : TypedResults.NotFound();
})
.WithName("GetUserByPhoneNumber");

profileApi.MapPost("/update", async Task<Results<Ok<Guid?>, InternalServerError>> (EditUserCommand cmd, IMediator mediator) =>
{
    var pid = await mediator.Send(cmd);
    return pid == null ? TypedResults.InternalServerError() : TypedResults.Ok(pid);
})
.WithName("UpdateUser");

profileApi.MapGet("/getroles", async (IMediator mediator) => await mediator.Send(new GetAllRolesQuery()))
.WithName("GetRoles");

profileApi.MapPost("/addrole", async Task<Results<Ok, BadRequest>> (CreateRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.BadRequest());

profileApi.MapPost("/updaterole", async Task<Results<Ok, InternalServerError>> (EditRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapPost("/deleterole", async Task<Results<Ok, InternalServerError>> (DeleteRoleCommand cmd, IMediator mediator)
    => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapGet("/manageusers/{roleName}", async (string roleName, IMediator mediator)
            => await mediator.Send(new GetUsersInRoleQuery(roleName)));

profileApi.MapPost("/addusertorole", async Task<Results<Ok, InternalServerError>> (AddUserToRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapPost("/removeuserfromrole", async Task<Results<Ok, InternalServerError>> (RemoveUserFromRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());


var addressApi = app.MapGroup("/api/addresses").RequireAuthorization();



app.Run();
