﻿window.bafmapLocationPicker = {

    maps: {},

    initialize: function (
        mapId,
        latitude,
        longitude,
        zoom,
        dotNetReference) {

        const element = document.getElementById(mapId);

        if (!element) {
            console.error("Carte introuvable : " + mapId);
            return;
        }

        // Création de la carte
        const map = L.map(mapId).setView([latitude, longitude], zoom);

        // OpenStreetMap
        L.tileLayer("https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            {
                maxZoom: 21,
                attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">' + 'OpenStreetMap</a>'
            }
        ).addTo(map);

        // Marqueur
        const marker = L.marker([latitude, longitude],
            {
                draggable: true
            }
        ).addTo(map);

        // Déplacement du marqueur
        marker.on("dragend",
            function () {
                const position = marker.getLatLng();

                dotNetReference.invokeMethodAsync("MarkerMoved", position.lat, position.lng);
            }
        );

        map.on("dblclick",
            function (event) {

                const latitude = event.latlng.lat;

                const longitude = event.latlng.lng;

                marker.setLatLng([latitude, longitude]);

                dotNetReference.invokeMethodAsync("MarkerMoved", latitude, longitude);
            }
        );

        navigator.geolocation.getCurrentPosition(success, error, options);

        function success(position) {
            var coords = position.coords;

            const instance = this.maps[mapId];

            if (!instance) {
                return;
            }

            const currentposition = [
                coords.latitude,
                coords.longitude
            ];

            instance.mainmarker.setLatLng(currentposition);

            // Cercle de précision
            if (instance.accuracyCircle) {
                instance.accuracyCircle.setLatLng(position);
            }

            dotNetReference.invokeMethodAsync("CurrentPositionReceived", coords.latitude, coords.longitude, coords.accuracy);
        }

        function error(err) {
            console.error("Erreur GPS :", err.message);
        }

        var options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }

        // Stockage
        this.maps[mapId] = {
            map: map,
            marker: marker,
            accuracyCircle: true,
            userLocationMarker: null,
            dotNetReference: dotNetReference
        };
    },

    getCurrentPosition: function () {

        navigator.geolocation.getCurrentPosition(success, error, options);

        function success(position) {
            const instance = this.maps[mapId];
            var coords = position.coords;

            // Marqueur principal
            const mainmarker = L.marker([coords.latitude, coords.longitude],
                {
                    draggable: false
                }
            ).addTo(instance.map);
        }

        function error(err) {
            console.error("Erreur GPS :", err.message);
        }

        var options = {
            enableHighAccuracy: true,
            timeout: 10000,
            maximumAge: 0
        }
    },

    setMarkerPosition: function (mapId, latitude, longitude, centerMap) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        const position = [latitude, longitude];

        instance.mainmarker.setLatLng(position);

        // Cercle de précision
        if (instance.accuracyCircle) {
            instance.accuracyCircle.setLatLng(position);
        }

        if (centerMap) {
            instance.map.setView(position, instance.map.getZoom());
        }
    },

    // Suppression
    dispose: function (mapId) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        instance.map.remove();

        delete this.maps[mapId];
    }
};