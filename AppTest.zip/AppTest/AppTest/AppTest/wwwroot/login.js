﻿window.bafmapLogin = {

    focusPassword: function () {

        const password = document.getElementById("password");

        if (password) {
            password.focus();
        }
    }

}