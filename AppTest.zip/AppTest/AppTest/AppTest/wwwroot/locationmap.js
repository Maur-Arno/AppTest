﻿window.bafMap = {

    maps: {},

    initialize: function (
        mapId,
        latitude,
        longitude,
        zoom,
        showZoomControls,
        showUserLocation,
        dotNetReference) {

        const element = document.getElementById(mapId);

        if (!element) {
            return;
        }

        const map =
            L.map(mapId, {

                zoomControl: showZoomControls,

                attributionControl: true

            }).setView(
                [latitude, longitude],
                zoom
            );


        // OPEN STREET MAP
        L.tileLayer(
            "https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png",
            {
                maxZoom: 21,
                attribution: '&copy; OpenStreetMap contributors'
            }
        ).addTo(map);

        // STORAGE
        this.maps[mapId] = {
            map: map,
            markers: {},
            userMarker: null,
            accuracyCircle: null,
            dotNetReference: dotNetReference,
            showUserLocation: showUserLocation
        };
    },

    // SET PLACES
    setPlaces: function (mapId, places) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        // Supprimer les anciens marqueurs
        Object.values(instance.markers).forEach(function (marker) {
            instance.map.removeLayer(marker);
        });

        instance.markers = {};

        // Ajouter les nouveaux
        places.forEach(function (place) {

            const marker = L.marker([place.latitude, place.longitude]);

            marker.addTo(instance.map);

            const popup = `
                    <div class="baf-map-popup">

                        <div class="popup-category">
                            ${place.category ?? ""}
                        </div>

                        <div class="popup-name">
                            ${place.name}
                        </div>

                        <div class="popup-reference">
                            ${place.reference}
                        </div>

                        <div class="popup-district">
                            📍 ${place.district}
                        </div>

                        <button class="popup-button" onclick="
                                window.bafMap.selectPlace(
                                        '${mapId}',
                                        '${place.reference}'
                                    )
                            ">
                            Voir la fiche
                        </button>

                    </div>
                `;

            marker.bindPopup(popup);

            instance.markers[place.id] = marker;
        }
        );
    },

    // SELECT PLACE
    selectPlace: function (mapId, placeId) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        const marker = instance.markers[placeId];

        if (marker) {
            marker.openPopup();
            instance.map.panTo(marker.getLatLng());
        }

        instance.dotNetReference.invokeMethodAsync("PlaceSelected", placeId);
    },

    // LOCALISATION
    locateUser: function (mapId, dotNetReference) {

        if (!navigator.geolocation) {
            console.error("Géolocalisation indisponible.");
            return;
        }

        navigator.geolocation.getCurrentPosition(

            function (position) {

                const latitude = position.coords.latitude;

                const longitude = position.coords.longitude;

                const accuracy = position.coords.accuracy;

                const instance = window.bafMap.maps[mapId];

                if (!instance) {
                    return;
                }

                const positionLatLng = [latitude, longitude];

                // USER MARKER
                if (!instance.userMarker) {
                    instance.userMarker = L.marker(positionLatLng).addTo(instance.map);
                }
                else {
                    instance.userMarker.setLatLng(positionLatLng);
                }

                // CERCLE PRÉCISION
                if (!instance.accuracyCircle) {

                    instance.accuracyCircle =
                        L.circle(
                            positionLatLng,
                            {
                                radius: accuracy,

                                fillOpacity: 0.15,

                                weight: 1
                            }
                        ).addTo(instance.map);
                }
                else {
                    instance.accuracyCircle.setLatLng(positionLatLng);
                    instance.accuracyCircle.setRadius(accuracy);
                }

                // CENTRAGE
                instance.map.setView(
                    positionLatLng,
                    Math.max(instance.map.getZoom(), 17)
                );

                // C#
                dotNetReference.invokeMethodAsync("UserLocationReceived",
                    latitude,
                    longitude,
                    accuracy
                );
            },

            function (error) {
                console.error("Erreur GPS :", error.message);
            },
            {
                enableHighAccuracy: true,
                timeout: 15000,
                maximumAge: 0
            }
        );
    },

    // CENTER
    centerOn: function (mapId, latitude, longitude, zoom) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        instance.map.setView([latitude, longitude], zoom);
    },

    // DISPOSE
    dispose: function (mapId) {

        const instance = this.maps[mapId];

        if (!instance) {
            return;
        }

        instance.map.remove();

        delete this.maps[mapId];
    }
};