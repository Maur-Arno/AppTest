using AKSoftware.Localization.MultiLanguages;
using AKSoftware.Localization.MultiLanguages.Providers;
using MediatR;
using Microsoft.AspNetCore.Antiforgery;
using Microsoft.AspNetCore.Authentication.JwtBearer;
using Microsoft.AspNetCore.Http.HttpResults;
using Microsoft.AspNetCore.HttpOverrides;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.ResponseCompression;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Caching.Memory;
using Microsoft.IdentityModel.Tokens;
using Microsoft.OpenApi;
using MudBlazor;
using MudBlazor.Services;
using Profiler.Client.Services;
using Profiler.Client.Shared;
using Profiler.Components;
using Profiler.Infrastructure;
using Profiler.Infrastructure.Persistence;
using Profiler.Needs;
using Profiler.Needs.Services;
using Profiler.Needs.UseCases.Commands.AddUserToRole;
using Profiler.Needs.UseCases.Commands.ConfirmPhoneNumber;
using Profiler.Needs.UseCases.Commands.CreateAd;
using Profiler.Needs.UseCases.Commands.CreateRole;
using Profiler.Needs.UseCases.Commands.CreateUser;
using Profiler.Needs.UseCases.Commands.DeleteRole;
using Profiler.Needs.UseCases.Commands.EditAd;
using Profiler.Needs.UseCases.Commands.EditRole;
using Profiler.Needs.UseCases.Commands.EditUser;
using Profiler.Needs.UseCases.Commands.RemoveUserFromRole;
using Profiler.Needs.UseCases.Commands.UpdateUserIdCard;
using Profiler.Needs.UseCases.Queries.GetAllRoles;
using Profiler.Needs.UseCases.Queries.GetAnnouncements;
using Profiler.Needs.UseCases.Queries.GetAnnouncementsSearch;
using Profiler.Needs.UseCases.Queries.GetProfileByName;
using Profiler.Needs.UseCases.Queries.GetProfileByPhoneNumber;
using Profiler.Needs.UseCases.Queries.GetProfileCitiesOccupations;
using Profiler.Needs.UseCases.Queries.GetProfilesSearch;
using Profiler.Needs.UseCases.Queries.GetProfilesSinceToken;
using Profiler.Needs.UseCases.Queries.GetUsersInRole;
using Profiler.Needs.UseCases.Queries.LogInUser;
using Profiler.Shared.DTOs;
using System.Reflection;
using System.Text;
using System.Text.Json;
using System.Threading.RateLimiting;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Logging.ClearProviders();
builder.Logging.AddConsole();
builder.Services.AddOptions();
// Learn more about configuring OpenAPI at https://aka.ms/aspnet/openapi
builder.Services.AddOpenApi(options =>
{
    options.AddDocumentTransformer((document, context, _) =>
    {
        // Set API metadata
        document.Info = new OpenApiInfo
        {
            Title = "Profiler API",
            Version = "v1",
            Description = "This is a sample API wich will help you in Profiler management."
        };

        // Add a global security scheme
        document.Components ??= new();
        document.Components.SecuritySchemes ??= new Dictionary<string, IOpenApiSecurityScheme>
        {
            {
                "Bearer",
                new OpenApiSecurityScheme
                {
                    Type = SecuritySchemeType.Http,
                    Scheme = "bearer",
                    BearerFormat = "JWT",
                    Description = "JWT Authorization header using the Bearer scheme."
                }
            }
        };

        // Apply security globally
        document.Security ??=
        [
            new OpenApiSecurityRequirement
            {
                {
                    new OpenApiSecuritySchemeReference("Bearer"),
                    new List<string>()
                }
            }
        ];

        return Task.CompletedTask;
    });
});

builder.Services.AddInfrastructureDI(builder.Configuration.GetConnectionString("ProfileDbConnection"));
builder.Services.AddNeedsDI();
builder.Services.AddDistributedMemoryCache(); // Pour stocker les Sessions.
builder.Services.AddSession(options =>
{
    options.IdleTimeout = TimeSpan.FromMinutes(20);
    options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    options.Cookie.SameSite = SameSiteMode.Lax;
    options.Cookie.HttpOnly = true;
    options.Cookie.IsEssential = true;
});
builder.Services.AddAuthentication(options =>
{
    options.DefaultAuthenticateScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultChallengeScheme = JwtBearerDefaults.AuthenticationScheme;
    options.DefaultScheme = JwtBearerDefaults.AuthenticationScheme;
})
    .AddCookie(options =>
    {
        options.Cookie.SecurePolicy = CookieSecurePolicy.Always;
        options.Cookie.SameSite = SameSiteMode.Lax;
        options.Cookie.HttpOnly = true;
        options.Cookie.IsEssential = true;
    })
    .AddJwtBearer(options =>
    {
        options.SaveToken = true;
        options.RequireHttpsMetadata = false;
        options.TokenValidationParameters = new TokenValidationParameters()
        {
            ValidateIssuer = true,
            ValidateAudience = true,
            ValidateLifetime = true,
            ValidateIssuerSigningKey = true,
            ValidIssuer = builder.Configuration["Jwt:Issuer"],
            ValidAudience = builder.Configuration["Jwt:Audience"],
            IssuerSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(builder.Configuration["Jwt:key"]!))
        };
    });
builder.Services.AddAuthorization();

// configure Asp.Net Core Identity cookies
builder.Services.ConfigureApplicationCookie(option =>
{
    option.Cookie.SecurePolicy = CookieSecurePolicy.Always;
    option.Cookie.SameSite = SameSiteMode.Lax;
    option.ExpireTimeSpan = TimeSpan.FromHours(2);
    option.Cookie.HttpOnly = true;
    option.SlidingExpiration = true;
    option.Events.OnRedirectToLogin = context =>
    {
        if (context.Request.Path.StartsWithSegments("/api"))
        {
            context.Response.StatusCode = 401;
            return Task.CompletedTask;
        }
        context.Response.Redirect(context.RedirectUri);
        return Task.CompletedTask;
    };
});

// Configur tous les cookies (essentiels: auth, session) par défaut
builder.Services.Configure<CookiePolicyOptions>(option =>
{
    option.CheckConsentNeeded = _ => true;
    option.MinimumSameSitePolicy = SameSiteMode.Lax;
    option.Secure = CookieSecurePolicy.Always;
    option.OnAppendCookie = context =>
    {
        context.CookieOptions.HttpOnly = true;
        context.CookieOptions.SameSite = SameSiteMode.Lax;
    };
});

// Controle tous les tokens générés pour les email/phonenumber confirmation, password reset, two-fator...
builder.Services.Configure<DataProtectionTokenProviderOptions>(o =>
    o.TokenLifespan = TimeSpan.FromHours(3)); // changes all data protection tokens timeout period to 3 hours.

// protège contr l'attaque force-brute.
builder.Services.AddRateLimiter(options =>
{
    options.GlobalLimiter = PartitionedRateLimiter.Create<HttpContext, string>(httpContext =>
    {
        var key = httpContext.User.Identity?.Name ?? httpContext.Connection.RemoteIpAddress?.ToString() ?? "anonymous";
        return RateLimitPartition.GetFixedWindowLimiter(key, _ => new FixedWindowRateLimiterOptions
        {
            PermitLimit = 100,
            Window = TimeSpan.FromMinutes(1),
            QueueProcessingOrder = QueueProcessingOrder.OldestFirst,
            QueueLimit = 2
        });
    });
    options.RejectionStatusCode = StatusCodes.Status429TooManyRequests;
});

builder.Services.AddHealthChecks();

// Compresser les réponses seveur -> client pour une meilleure latence.
builder.Services.AddResponseCompression(options =>
{
    options.Providers.Add<BrotliCompressionProvider>();
    options.Providers.Add<GzipCompressionProvider>();
    options.EnableForHttps = true;
    options.MimeTypes = ResponseCompressionDefaults.MimeTypes.Concat(["application/octet-stream", "image/svg+xml"]);
});
builder.Services.AddValidation();

// Lutter contre les attaques CSRF !
builder.Services.AddAntiforgery(options =>
{
    options.HeaderName = "X-CSRF-TOKEN";
    options.Cookie.Name = "X-CSRF-COOKIE";
});

builder.Services.AddMudServices(config =>
{
    config.SnackbarConfiguration.PositionClass = Defaults.Classes.Position.BottomRight;
    config.SnackbarConfiguration.ShowTransitionDuration = 400;
    config.SnackbarConfiguration.HideTransitionDuration = 400;
});
builder.Services.AddMemoryCache();
builder.Services.AddLanguageContainerForBlazorServer(typeof(Program).Assembly);
builder.Services.AddScoped<NetworkDevice>();
builder.Services.AddScoped<ICryptoService, CryptoService>();
builder.Services.AddScoped(sp => new HttpClient());

// Add services to the container.
builder.Services.AddRazorComponents()
    .AddInteractiveServerComponents()
    .AddInteractiveWebAssemblyComponents();

var app = builder.Build();

var newServiceProviderScope = app.Services.GetRequiredService<IServiceScopeFactory>().CreateScope().ServiceProvider;
// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseWebAssemblyDebugging();
    app.MapOpenApi();    // /openapi/v1.json
    DeveloperExceptionPageOptions pageOptions = new() { SourceCodeLineCount = 10 };
    app.UseDeveloperExceptionPage(pageOptions);
    await newServiceProviderScope.InitializeDbAsync();
}
else
{
    // proxy / Load balancer
    app.UseForwardedHeaders(new ForwardedHeadersOptions
    {
        ForwardedHeaders = ForwardedHeaders.XForwardedFor | ForwardedHeaders.XForwardedProto
    });

    app.UseExceptionHandler("/Error", createScopeForErrors: true);
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}
app.UseStatusCodePagesWithReExecute("/not-found", createScopeForStatusCodePages: true);
app.UseHttpsRedirection();
app.UseResponseCompression();
//app.UseStaticFiles(new StaticFileOptions
//{
//    FileProvider = new PhysicalFileProvider(Path.Combine(builder.Environment.ContentRootPath, "public")),
//    RequestPath = "/static"
//});
app.UseCookiePolicy();
app.UseRouting();
app.UseAuthentication();
app.UseSession();
app.UseAuthorization();
app.UseAntiforgery();
app.UseRateLimiter();

app.MapStaticAssets();
app.MapRazorComponents<App>()
    .AddInteractiveServerRenderMode()
    .AddInteractiveWebAssemblyRenderMode()
    .AddAdditionalAssemblies(typeof(Profiler.Client._Imports).Assembly);

app.MapGet("/api", (HttpContext httpCtxt, IAntiforgery antif) =>
{
    var tokens = antif.GetAndStoreTokens(httpCtxt);
    httpCtxt.Response.Cookies.Append(tokens?.HeaderName!, tokens?.CookieToken!);
    return Results.Ok("Profiler API (-_-)");
})
.WithName("XSRFProfilerAPI")
.WithSummary("Insère un jeton anti contrefaçon")
.Produces(StatusCodes.Status200OK);

var allApi = app.MapGroup("/api/auth").WithTags("Authentication");

allApi.MapPost("/register", async Task<Results<Created, InternalServerError>> (CreateUserCommand cmd, IMediator mediator) => await mediator.Send(cmd)
                                                                    ? TypedResults.Created()
                                                                    : TypedResults.InternalServerError())
.WithName("CreateProfile")
.WithSummary("Crée un utilisateur")
.Accepts<CreateUserCommand>("application/json")
.Produces<CreateUserCommand>(StatusCodes.Status201Created)
.Produces(StatusCodes.Status500InternalServerError);

allApi.MapPost("/verify", async Task<Results<Ok, InternalServerError>> (ConfirmPhoneNumberCommand cmd, IMediator mediator) => await mediator.Send(cmd)
                                                                    ? TypedResults.Ok()
                                                                    : TypedResults.InternalServerError())
          .WithName("VerifyProfile");

allApi.MapPost("/login", async Task<Results<Ok<LoginResponseDto>, BadRequest<string>>> (GetUserCredentialQuery query, HttpContext httpCtxt, IMediator mediator) =>
{
    var userCredentials = await mediator.Send(query);

    if (userCredentials != null)
    {
        httpCtxt.Response.Cookies.Append("refresh", userCredentials.RefreshToken);
        return TypedResults.Ok(new LoginResponseDto(userCredentials.UserName,
                                                    userCredentials.AccessToken,
                                                    new OfflineToken(userCredentials.Id, query.DeviceId, DateTimeOffset.UtcNow.AddDays(7)))
                              );
    }
    else
        return TypedResults.BadRequest("BadPhoneNumberOrPassword");
})
.WithName("Login")
.Accepts<GetUserCredentialQuery>("application/json");

allApi.MapPost("/refresh", async (string deviceId, HttpContext httpCtxt, ITokenService tokenService) =>
{
    if (!httpCtxt.Request.Cookies.TryGetValue("refresh", out var refreshToken))
        return Results.Unauthorized();

    var dbContext = newServiceProviderScope.GetRequiredService<ProfileContext>();

    if (string.IsNullOrWhiteSpace(refreshToken) || !await dbContext.RefreshTokens.AnyAsync(t => t.Token == refreshToken && !t.IsRevoked))
        return Results.Unauthorized();

    var singleDbRefreshToken = await dbContext.RefreshTokens.SingleAsync(t => t.Token == refreshToken && !t.IsRevoked);
    var user = await dbContext.Users.FirstOrDefaultAsync(p => p.Id == singleDbRefreshToken.ProfilerId);
    if (user == null || !await tokenService.ValidateteRefreshTokenAsync(refreshToken, user.Id, deviceId))
        return Results.Unauthorized();

    var newToken = await tokenService.CreateAccessTokenAsync(user);
    var newRefresh = await tokenService.CreateRefreshTokenAsync(user.Id, deviceId);

    httpCtxt.Response.Cookies.Append("refresh", newRefresh!);

    return Results.Ok(new { accessToken = newToken });
})
.WithName("RefreshToken");

var profileApi = app.MapGroup("/api/profile").RequireAuthorization();

profileApi.MapGet("/cities", async (IMediator mediator)
    => await mediator.Send(new GetProfileCitiesOccupationsQuery()));

profileApi.MapPost("/search", async Task<Results<Ok<ProfileDto[]>, NotFound>> (GetProfilesSearchQuery query, IMediator mediator) =>
{
    if (string.IsNullOrWhiteSpace(query.City) || string.IsNullOrWhiteSpace(query.Occupation))
        return TypedResults.NotFound();

    var result = await mediator.Send(query);
    return result != null && result.Length > 0 ? TypedResults.Ok(result) : TypedResults.NotFound();
})
.WithName("GetProfileSearch");

profileApi.MapPost("/username", async Task<Results<Ok<ProfileDto>, NotFound>> (GetProfileByNameQuery query, IMediator mediator) =>
{
    var result = await mediator.Send(query);
    return result != null ? TypedResults.Ok(result) : TypedResults.NotFound();
})
.WithName("GetProfileByUserName");

profileApi.MapGet("/{number:length(9)}", async Task<Results<Ok<ProfileDto>, NotFound>> (string number, IMediator mediator) =>
{
    var user = await mediator.Send(new GetProfileByPhoneNumberQuery(number));
    return user != null ? TypedResults.Ok(new ProfileDto(user.Id, user.NIN!, user.IdCardNumber!, user.UserName!, user.BirthDate,
                user.Address?.City!, user.Address?.StreetAddress, user.Gender!, user.PhoneNumber!, user.Nationality!, user.Occupation!, user.DateOfIssue, user.ExpirationDate, user.ProfilePicture!, user.CV!, user.LastModified, user.Version)) : TypedResults.NotFound();
})
.WithName("GetProfileByPhoneNumber");

profileApi.MapPost("/update", async Task<Results<Ok<Guid?>, InternalServerError>> (EditUserCommand cmd, IMediator mediator) =>
{
    var pid = await mediator.Send(cmd);
    return pid == null ? TypedResults.InternalServerError() : TypedResults.Ok(pid);
})
.WithName("UpdateOnProfile");

profileApi.MapPost("/read/{number:length(9)}", async Task<Results<Ok<ProfileDto>, BadRequest<string>>> (string number, HttpContext httpCtxt, IMediator mediator) =>
{
    if (httpCtxt.Request.Form.Files.Count < 1)
        return TypedResults.BadRequest("BadIdCardImage");

    var user = await mediator.Send(new UpdateUserIdCardQuery(number, httpCtxt.Request.Form.Files[0]));
    return user != null ? TypedResults.Ok(user) : TypedResults.BadRequest("BadIdCardImage");
})
.WithName("ReadIdCardImage")
.Accepts<object>("multipart/form-data");

profileApi.MapGet("/getroles", async (IMediator mediator) => await mediator.Send(new GetAllRolesQuery()))
.WithName("GetRoles");

profileApi.MapPost("/addrole", async Task<Results<Ok, BadRequest>> (CreateRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.BadRequest());

profileApi.MapPost("/updaterole", async Task<Results<Ok, InternalServerError>> (EditRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapPost("/deleterole", async Task<Results<Ok, InternalServerError>> (DeleteRoleCommand cmd, IMediator mediator)
    => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapGet("/manageusers/{roleName}", async (string roleName, IMediator mediator)
            => await mediator.Send(new GetUsersInRoleQuery(roleName)));

profileApi.MapPost("/addusertorole", async Task<Results<Ok, InternalServerError>> (AddUserToRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

profileApi.MapPost("/removeuserfromrole", async Task<Results<Ok, InternalServerError>> (RemoveUserFromRoleCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

var announcementApi = app.MapGroup("/api/announcement").RequireAuthorization();

announcementApi.MapPost("/add", async Task<Results<Ok, BadRequest>> (CreateAdCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.BadRequest());

announcementApi.MapPost("/update", async Task<Results<Ok, InternalServerError>> (EditAdCommand cmd, IMediator mediator)
            => await mediator.Send(cmd) ? TypedResults.Ok() : TypedResults.InternalServerError());

announcementApi.MapGet("/getannouncements/{number:length(9)}", async (string number, IMediator mediator) => await mediator.Send(new GetAnnouncementsQuery(number)))
.WithName("GetAnnouncements");

announcementApi.MapGet("/search/{query}", async Task<Results<Ok<AdDto[]>, NotFound>> (string query, IMediator mediator) =>
{
    if (string.IsNullOrWhiteSpace(query))
        return TypedResults.NotFound();

    var result = await mediator.Send(new GetAnnouncementsSearchQuery(query));
    return result != null && result.Length > 0 ? TypedResults.Ok(result) : TypedResults.NotFound();
})
.WithName("GetAnnouncementSearch");

profileApi.MapPut("/push", async Task<Results<Ok<PushResponseDto>, InternalServerError>> ([FromBody] PushRequestDto requestDto, IMediator mediator) =>
{
    var requestPayload = JsonSerializer.Deserialize<List<EditUserCommand>>(requestDto.PayloadJson);
    if (requestPayload != null && requestPayload.Count != 0)
    {
        var results = new List<PushResponseItemDto>();
        foreach (var cmd in requestPayload)
        {
            var resultId = await mediator.Send(cmd);
            if (resultId == null)
                results.Add(new PushResponseItemDto(false, cmd.PhoneNumber));
            else
                results.Add(new PushResponseItemDto(true, resultId.ToString()));
        }
        return TypedResults.Ok(new PushResponseDto(results));
    }
    return TypedResults.InternalServerError();
})
.WithName("UpdateOffProfile");

profileApi.MapGet("/pull/{since}", async Task<Results<Ok<PullResponseDto>, NotFound>> (string? since, IMediator mediator) =>
{

    var response = await mediator.Send(new GetProfilesSinceTokenQuery(since));
    if (response == null)
        return TypedResults.NotFound();
    else
    {
        var newToken = DateTimeOffset.UtcNow.ToString("O");
        return TypedResults.Ok(new PullResponseDto(JsonSerializer.Serialize(response), newToken));
    }
})
.WithName("GetProfilesSinceToken")
.Produces(StatusCodes.Status200OK)
.Produces(StatusCodes.Status404NotFound);

app.Run();
