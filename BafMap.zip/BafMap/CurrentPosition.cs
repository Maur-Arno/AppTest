﻿namespace BafMap.Client
{
    public class CurrentPosition
    {
        double Latitude { get; set; }
        double Longitude { get; set; }
        double Precision { get; set; }
    }
}
