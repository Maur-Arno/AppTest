﻿using Microsoft.JSInterop;
using System.Text.Json;

namespace BafMap.Client
{
    public class NetworkDevice(IJSRuntime js)
    {
        private readonly IJSRuntime _js = js;
        private const string MetaStore = "usermetadata";

        public async Task<bool> IsOnline()
        {
            return await _js.InvokeAsync<bool>("isOnline");
        }

        public async Task<CurrentPosition> GetCurrentPosition()
        {
            return await _js.InvokeAsync<CurrentPosition>("getCurrentPosition");
        }

        public async Task<CurrentPosition> GetMarker()
        {
            return await _js.InvokeAsync<CurrentPosition>("getMarker");
        }

        public static async Task<string?> GetOrCreateDeviceIdAsync(IJSObjectReference module)
        {
            var existing = await module.InvokeAsync<object>("get", MetaStore, "deviceId");
            if (existing == null)
            {
                var deviceId = await module.InvokeAsync<string>("generateDeviceId");
                await module.InvokeVoidAsync("put", MetaStore, new { key = "deviceId", value = deviceId });
                return deviceId;
            }
            using var doc = JsonDocument.Parse(JsonSerializer.Serialize(existing));
            if (doc.RootElement.TryGetProperty("value", out var id))
                return id.GetString()!;

            return null;
        }
    }
}
