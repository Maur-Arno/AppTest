﻿namespace BafMap.Services.DTOs
{
    public record ManageUsersDto(
        UserRoleDto[]? UsersInRole,
        UserRoleDto[]? UsersOutOfRole
        );
}
