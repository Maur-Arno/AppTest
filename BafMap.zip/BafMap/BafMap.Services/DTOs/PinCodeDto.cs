﻿namespace BafMap.Services.DTOs
{
    public record PinCodeDto(
        string PhoneNumber,
        string PinCode
        );
}
