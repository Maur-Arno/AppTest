﻿namespace BafMap.Services.DTOs
{
    public record RoleDto(
        string Name,
        string Description
        );
}
