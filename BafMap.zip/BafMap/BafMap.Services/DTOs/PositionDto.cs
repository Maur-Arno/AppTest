﻿namespace BafMap.Services.DTOs
{
    public record PositionDto(
        double Longitude, 
        double Latitude
        );
}
