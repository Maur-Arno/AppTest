﻿namespace BafMap.Services.DTOs
{
    public record UserRoleDto(
        string PhoneNumber,
        string RoleName
        );
}
