﻿namespace BafMap.Services.DTOs
{
    public record UserCredentialDto(
        string UserName,
        string Token,
        DateTime? Expires
        );
}
