﻿namespace BafMap.Services.DTOs
{
    public record UserDto(
        string UserName,
        string Gender,
        string PhoneNumber,
        int Version
        );
}
