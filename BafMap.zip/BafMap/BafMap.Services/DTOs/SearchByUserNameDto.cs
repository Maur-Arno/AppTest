﻿namespace BafMap.Services.DTOs
{
    public record SearchByUserNameDto(
        string UserName,
        IReadOnlyCollection<string>? Cities,
        IReadOnlyCollection<string>? Occupations
    );
}
