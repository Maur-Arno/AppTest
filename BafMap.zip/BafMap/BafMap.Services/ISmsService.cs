﻿namespace BafMap.Services
{
    public interface ISmsService
    {
        public bool CanSendOtp(string phoneNumber);
        Task<bool> SendSmsAsync(string phoneNumber, string token);
    }
}
