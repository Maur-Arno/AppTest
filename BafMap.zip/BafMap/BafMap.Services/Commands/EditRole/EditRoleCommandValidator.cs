﻿using FluentValidation;

namespace BafMap.Services.Commands.EditRole
{
    public class EditRoleCommandValidator : AbstractValidator<EditRoleCommand>
    {
        public EditRoleCommandValidator()
        {
            RuleFor(x => x.RoleName)
            .NotEmpty().WithMessage("The name is required.");
        }
    }
}
