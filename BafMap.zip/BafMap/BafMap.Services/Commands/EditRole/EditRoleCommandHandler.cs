﻿using BafMap.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Commands.EditRole
{
    public sealed class EditRoleCommandHandler : IRequestHandler<EditRoleCommand, bool>
    {
        private readonly ILogger _logger;
        private readonly RoleManager<Role> _roleManager;
        private readonly UserManager<User> _UserManager;

        public EditRoleCommandHandler(RoleManager<Role> roleManager, UserManager<User> UserManager, ILoggerFactory factory)
        {
            _roleManager = roleManager;
            _UserManager = UserManager;
            _logger = factory.CreateLogger("EditRole");
        }

        public async Task<bool> Handle(EditRoleCommand request, CancellationToken cancellationToken)
        {
            var role = await _roleManager.Roles.FirstOrDefaultAsync(r => r.Name == request.RoleName, cancellationToken);
            if (role == null)
            {
                _logger.LogError($"The role with Name '{request.RoleName}' was not found");
                return false;
            }

            try
            {
                role.Name = request.RoleName;
                role.Description = request.Description;
                await _roleManager.UpdateAsync(role);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: EditRoleError : {body}", DateTime.UtcNow, ex.Message);
                return false;
            }
            
        }
    }
}
