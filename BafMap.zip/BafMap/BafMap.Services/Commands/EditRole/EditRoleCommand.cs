﻿using MediatR;

namespace BafMap.Services.Commands.EditRole
{
    public record EditRoleCommand(string RoleName, string Description) : IRequest<bool>;
}
