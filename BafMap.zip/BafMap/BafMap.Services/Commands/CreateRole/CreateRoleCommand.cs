﻿using MediatR;

namespace BafMap.Services.Commands.CreateRole
{
    public record CreateRoleCommand(
        string Name,
        string? Description
        ) : IRequest<bool>;
}
