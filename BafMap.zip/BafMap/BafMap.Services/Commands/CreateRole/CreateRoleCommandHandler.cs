﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using BafMap.Domain.Entities;
using BafMap.Infrastructure.Persistence;

namespace BafMap.Services.Commands.CreateRole
{
    public sealed class CreateRoleCommandHandler : IRequestHandler<CreateRoleCommand, bool>
    {
        private readonly ILogger _logger;
        private readonly RoleManager<Role> _roleManager;
        private readonly BafMapContext _ctx;

        public CreateRoleCommandHandler(BafMapContext ctx, RoleManager<Role> roleManager, ILoggerFactory factory)
        {
            _ctx = ctx;
            _roleManager = roleManager;
            _logger = factory.CreateLogger("CreateRole");
        }

        public async Task<bool> Handle(CreateRoleCommand request, CancellationToken cancellationToken)
        {
            if (await _roleManager.RoleExistsAsync(request.Name))
            {
                _logger.LogError($"The role with the name = '{request.Name}' already exist");
                return false;
            }

            using var trs = await _ctx.Database.BeginTransactionAsync(cancellationToken);

            IdentityResult result = await _roleManager.CreateAsync(new Role { Name = request.Name, Description = request.Description });
            if (result.Succeeded)
            {
                await trs.CommitAsync(cancellationToken);
                return true;
            }
            else
            {
                await trs.RollbackAsync(cancellationToken);
                foreach (var er in result.Errors)
                {
                    _logger.LogError("{Time}: Model State Error while attempting to create a new role => {Er}", DateTime.UtcNow, er.Description);
                }
                return false;
            }
        }
    }
}
