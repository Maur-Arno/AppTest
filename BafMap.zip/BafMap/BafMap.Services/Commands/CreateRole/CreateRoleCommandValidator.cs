﻿using FluentValidation;

namespace BafMap.Services.Commands.CreateRole
{
    public class CreateRoleCommandValidator : AbstractValidator<CreateRoleCommand>
    {
        public CreateRoleCommandValidator()
        {
            RuleFor(x => x.Name)
            .NotEmpty().WithMessage("The name is required.")
            .MaximumLength(60).WithMessage("The name cannot exceed 60 characters.");

            RuleFor(x => x.Description)
            .MaximumLength(60).WithMessage("The description cannot exceed 60 characters.");
        }
    }
}
