﻿using FluentValidation;
using BafMap.Services.Common;

namespace BafMap.Services.Commands.CreateUser
{
    public class CreateUserCommandValidator : AbstractValidator<CreateUserCommand>
    {
        public CreateUserCommandValidator()
        {
            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Phonenumber is required.")
            .Must(IsValid).WithMessage("Invalid Orange or MTN Phonenumber.");

            RuleFor(x => x.Password)
            .NotEmpty().WithMessage("Password is required.")
            .MinimumLength(8).WithMessage("Password must be at least of length 8")
            .Matches(@"[0-9]").WithMessage("Password must contain at least one digit")
            .Matches(@"[A-Z]").WithMessage("Password must contain at least one capital letter")
            .Matches(@"[a-z]").WithMessage("Password must contain at least one lowercase letter");

            //RuleFor(x => x.UserName)
            //.NotEmpty().WithMessage("The name is required.")
            //.MaximumLength(60).WithMessage("The name cannot exceed 60 characters.");

            //RuleFor(x => x.City)
            //.NotEmpty().WithMessage("The city is required.")
            //.MaximumLength(30).WithMessage("The name cannot exceed 30 characters.");

            //RuleFor(x => x.Gender)
            //.IsInEnum().WithMessage("Invalid gender.");

            //RuleFor(x => x.CountryCode)
            //.Matches(@"\d+").WithMessage("Not a country code.")
            //.MaximumLength(3).WithMessage("The country code cannot exceed 3 characters.")
            //.Must(Utilities.IsValidCountryCode).WithMessage("Not a valid country code.");

            //RuleFor(x => x.PhoneNumber)
            //.Matches(@"\d+").WithMessage("Not a phone number.")
            //.MaximumLength(9).WithMessage("The phone number cannot exceed 9 characters.")
            //.Must(IsValid).WithMessage("Must be Orange / Mtn number.");

            //RuleFor(x => x.OrderAmount)
            //.GreaterThan(0).WithMessage("Order amount must be greater than zero.");
        }

        private bool IsValid(string value)
        {
            return Utilities.IsValidOrangeNbr(value) || Utilities.IsValidMtnNbr(value);
        }
    }
}
