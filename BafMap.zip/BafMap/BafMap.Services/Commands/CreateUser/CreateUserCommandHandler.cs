﻿using BafMap.Domain.Entities;
using BafMap.Infrastructure;
using BafMap.Services.Common;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Commands.CreateUser
{
    public sealed class CreateUserCommandHandler(IUnitOfWork uow, UserManager<User> UserManager, ILoggerFactory factory, ISmsService sms) : IRequestHandler<CreateUserCommand, bool>
    {
        private readonly ILogger _logger = factory.CreateLogger("CreateUser");
        private readonly UserManager<User> _UserManager = UserManager;
        private readonly IUnitOfWork _unitOfWork = uow;
        private readonly ISmsService _sms = sms;

        public async Task<bool> Handle(CreateUserCommand request, CancellationToken cancellationToken)
        {
            if (_UserManager.Users.Any(c => c.PhoneNumber == request.PhoneNumber))
            {
                _logger.LogError("{Time}: User with Phonenumber '{phonenumber}' already exists", DateTime.UtcNow, request.PhoneNumber);
                return false;
            }

            if (Utilities.GetOperatorType(request.PhoneNumber) == 0)
            {
                _logger.LogError("{Time}: Bad Country Operator '{phonenumber}'", DateTime.UtcNow, request.PhoneNumber);
                return false;
            }

            var user = new User()
            {
                SecurityStamp = Guid.NewGuid().ToString(),
                UserName = request.Pseudo,
                PhoneNumber = request.PhoneNumber,
                CreatedAt = DateTime.UtcNow,
                LastModified = DateTimeOffset.UtcNow,
                Version = 1
            };

            using var trs = await _unitOfWork.BeginTransactionAsync(cancellationToken);
            try
            {
                var result = await _UserManager.CreateAsync(user, request.Password);
                if (result.Succeeded)
                {
                    var addToRoleResult = await _UserManager.AddToRoleAsync(user, "User");
                    if (addToRoleResult.Succeeded)
                    {
                        var token = await _UserManager.GenerateChangePhoneNumberTokenAsync(user, user.PhoneNumber!);
                        if (_sms.CanSendOtp(user.PhoneNumber))
                        {
                            var response = await _sms.SendSmsAsync(user.PhoneNumber, token);
                            if (response)
                            {
                                await trs.CommitAsync(cancellationToken);
                                return true;
                            }
                            else
                            {
                                await trs.RollbackAsync(cancellationToken);
                                //_logger.LogError("{Time}: Error while attempting to send token to new user => {Er}", DateTime.UtcNow, response.Body);
                                return false;
                            }
                        }
                        else
                        {
                            await trs.RollbackAsync(cancellationToken);
                            _logger.LogError("{Time}: Too many attempts => {phone}", DateTime.UtcNow, user.PhoneNumber);
                            return false;
                        }
                    }
                    else
                    {
                        await trs.RollbackAsync(cancellationToken);
                        foreach (var item in addToRoleResult.Errors)
                        {
                            _logger.LogError("{Time}: Error while attempting to add new user to role => {Er}", DateTime.Now, item.Description);
                        }
                        return false;
                    }
                }
                else
                {
                    await trs.RollbackAsync(cancellationToken);
                    foreach (var item in result.Errors)
                    {
                        _logger.LogError("{Time}: Error while attempting to create a new user => {Er}", DateTime.UtcNow, item.Description);
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                await trs.RollbackAsync(cancellationToken);
                _logger.LogError("{Time}: Error while creating a new user/role => {Er}", DateTime.UtcNow, ex.Message);
                return false;
            }
        }
    }
}
