﻿using MediatR;

namespace BafMap.Services.Commands.CreateUser
{
    public record CreateUserCommand(
        string Pseudo,
        string PhoneNumber,
        string Password,
        string DeviceId
        ) : IRequest<bool>;
}
