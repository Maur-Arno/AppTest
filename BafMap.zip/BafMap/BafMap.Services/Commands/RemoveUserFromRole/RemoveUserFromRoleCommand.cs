﻿using MediatR;

namespace BafMap.Services.Commands.RemoveUserFromRole
{
    public record RemoveUserFromRoleCommand(string PhoneNumber, string RoleName) : IRequest<bool>;
}
