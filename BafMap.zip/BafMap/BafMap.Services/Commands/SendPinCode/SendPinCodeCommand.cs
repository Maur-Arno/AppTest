﻿using MediatR;

namespace BafMap.Services.Commands.SendPinCode
{
    public record SendPinCodeCommand(string PhoneNumber) : IRequest<bool>;
}
