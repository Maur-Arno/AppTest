﻿using FluentValidation;

namespace BafMap.Services.Commands.SendPinCode
{
    public class SendPinCodeCommandValidator : AbstractValidator<SendPinCodeCommand>
    {
        public SendPinCodeCommandValidator()
        {
            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Email address is required.")
            .EmailAddress().WithMessage("Invalid email address.");
        }
    }
}
