﻿using BafMap.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Commands.SendPinCode
{
    public sealed class SendPinCodeCommandHandler(UserManager<User> UserManager, ILoggerFactory factory, ISmsService sms) : IRequestHandler<SendPinCodeCommand, bool>
    {
        private readonly ILogger _logger = factory.CreateLogger("SendPinCode");
        private readonly UserManager<User> _UserManager = UserManager;
        private readonly ISmsService _sms = sms;

        public async Task<bool> Handle(SendPinCodeCommand request, CancellationToken cancellationToken)
        {
            var user = await _UserManager.Users.FirstOrDefaultAsync(c => c.PhoneNumber == request.PhoneNumber);
            if (user == null)
            {
                _logger.LogError("{Time}: User with PhoneNumber = {phoneNumber} not found", DateTime.UtcNow, request.PhoneNumber);
                return false;
            }

            var token = await _UserManager.GenerateChangePhoneNumberTokenAsync(user, user.PhoneNumber!);
            var sended = await _sms.SendSmsAsync(user.PhoneNumber!, token);
            if (sended)
                return true;
            else
            {
                _logger.LogError("{Time}: Error while attempting to send token to new user", DateTime.UtcNow);
                return false;
            }
        }
    }
}
