﻿using BafMap.Domain.Entities;
using MediatR;

namespace BafMap.Services.Commands
{
    public record CreateLocationCommand(
        string Name,
        string City,
        string Quarter,
        LocationType Category,
        double Longitude,
        double Latitude,
        string Description,
        string PhotoUrl
        ) : IRequest<string>;
}
