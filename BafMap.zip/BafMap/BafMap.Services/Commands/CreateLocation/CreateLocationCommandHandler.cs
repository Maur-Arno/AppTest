﻿using BafMap.Domain.Ports;
using BafMap.Infrastructure;
using BafMap.Infrastructure.Exceptions;
using MediatR;
using NetTopologySuite.Geometries;

namespace BafMap.Services.Commands.CreateLocation
{
    public sealed class CreateLocationCommandHandler(
        ILocationReadRepository locationReadRepository,
        ILocationValidationRepository locationValidationRepository,
        IReferenceGenerator referenceGenerator,
        IUnitOfWork unitOfWork) : IRequestHandler<CreateLocationCommand, string>
    {
        private readonly ILocationReadRepository _locationReadRepository = locationReadRepository;
        private readonly ILocationValidationRepository _locationValidationRepository = locationValidationRepository;
        private readonly IReferenceGenerator _referenceGenerator = referenceGenerator;
        private readonly IUnitOfWork _unitOfWork = unitOfWork;

        public async Task<string> Handle(CreateLocationCommand command, CancellationToken cancellationToken)
        {
            using var transaction = await _unitOfWork.BeginTransactionAsync(cancellationToken);
            try
            {
                var reference = await _referenceGenerator.GenerateAsync(command.City[..3], command.Quarter[..3], command.Category.ToString(), cancellationToken);
                if (string.IsNullOrWhiteSpace(reference))
                    return reference;

                if (await _locationReadRepository.ExistsAddressReferenceAsync(reference))
                    throw new DuplicateReferenceException("La référence existe déjà.");

                bool addressAdded = false;
                var googlePlusCode = "";
                // Position géographique
                var point = new Point(command.Longitude, command.Latitude) { SRID = 4326 };

                // Vérifie un doublon d'adresse avant insertion
                if (await _locationReadRepository.ExistsNearByAsync(
                    command.Name,
                    command.Category,
                    command.Longitude,
                    command.Latitude,
                    10,
                    cancellationToken))
                {
                    addressAdded = await _locationValidationRepository.AddTempAddressAsync(new Domain.Entities.LocationRequest(
                                                                                                reference,
                                                                                                command.Name,
                                                                                                command.City,
                                                                                                command.Quarter,
                                                                                                command.Category,
                                                                                                googlePlusCode,
                                                                                                point,
                                                                                                command.Description,
                                                                                                command.PhotoUrl)
                                                                                           );

                    throw new DuplicateLocationException("Un bâtiment similaire existe déjà dans un rayon de 10 mètres. Souhaitez-vous consulter la fiche existante ou demander une création ?");
                }
                else
                {
                    addressAdded = await _locationValidationRepository.AddAddressAsync(new Domain.Entities.Address(
                                                                                                reference,
                                                                                                command.Name,
                                                                                                command.City,
                                                                                                command.Quarter,
                                                                                                command.Category,
                                                                                                googlePlusCode,
                                                                                                point,
                                                                                                command.Description,
                                                                                                command.PhotoUrl)
                                                                                           );
                    var refData = reference.Split("-");
                    if (uint.TryParse(refData[3], out uint refCode))
                        await _locationValidationRepository.RegisterReference(refData[0], refData[1], refData[2].ElementAt(0), refCode);
                    else
                        throw new NotRegisteredReferenceException($"{reference} Not registered!");
                }

                if (addressAdded)
                    await _unitOfWork.SaveChangesAsync(cancellationToken);

                await transaction.CommitAsync(cancellationToken);

                return reference;
            }
            catch
            {
                await transaction.RollbackAsync(cancellationToken);
                throw;
            }
        }
    }
}
