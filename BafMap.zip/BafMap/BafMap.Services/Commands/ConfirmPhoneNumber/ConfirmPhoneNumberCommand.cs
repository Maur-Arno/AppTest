﻿using MediatR;

namespace BafMap.Services.Commands.ConfirmPhoneNumber
{
    public record ConfirmPhoneNumberCommand(
        string PhoneNumber,
        string PinCode
        ) : IRequest<bool>;
}
