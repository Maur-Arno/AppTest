﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using BafMap.Domain.Entities;

namespace BafMap.Services.Commands.ConfirmPhoneNumber
{
    public sealed class ConfirmPhoneNumberCommandHandler : IRequestHandler<ConfirmPhoneNumberCommand, bool>
    {
        private readonly ILogger _logger;
        private readonly UserManager<User> _UserManager;

        public ConfirmPhoneNumberCommandHandler(UserManager<User> UserManager, ILoggerFactory factory)
        {
            _UserManager = UserManager;
            _logger = factory.CreateLogger("VerifyPinCode");
        }

        public async Task<bool> Handle(ConfirmPhoneNumberCommand request, CancellationToken cancellationToken)
        {
            var User = await _UserManager.Users.FirstOrDefaultAsync(c => c.PhoneNumber == request.PhoneNumber);
            if (User == null)
            {
                _logger.LogError("{Time}: User with PhoneNumber = {phoneNumber} not found", DateTime.UtcNow, request.PhoneNumber);
                return false;
            }

            var isValidToken = await _UserManager.VerifyChangePhoneNumberTokenAsync(User, request.PinCode, request.PhoneNumber);
            if (isValidToken)
            {
                User.PhoneNumberConfirmed = true;
                await _UserManager.UpdateAsync(User);
                return true;
            }
            else
            {
                _logger.LogError("{Time}: Verifying phoneNumber with code '{code}' was not be done", DateTime.UtcNow, request.PinCode);
                return false;
            }
        }
    }
}
