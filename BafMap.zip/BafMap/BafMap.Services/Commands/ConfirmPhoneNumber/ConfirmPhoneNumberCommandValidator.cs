﻿using FluentValidation;
using BafMap.Services.Common;

namespace BafMap.Services.Commands.ConfirmPhoneNumber
{
    public class ConfirmPhoneNumberCommandValidator : AbstractValidator<ConfirmPhoneNumberCommand>
    {
        public ConfirmPhoneNumberCommandValidator()
        {
            RuleFor(x => x.PinCode)
            .NotEmpty().WithMessage("The PIN code is required.")
            .MinimumLength(4).WithMessage("The PIN code must be at least of length 4.");

            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Phonenumber is required.")
            .Must(IsValid).WithMessage("Invalid Orange or MTN Phonenumber.");
        }

        private bool IsValid(string value)
        {
            return Utilities.IsValidOrangeNbr(value) || Utilities.IsValidMtnNbr(value);
        }
    }
}
