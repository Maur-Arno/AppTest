﻿using FluentValidation;
using BafMap.Services.Common;

namespace BafMap.Services.Commands.EditUser
{
    public class EditUserCommandValidator : AbstractValidator<EditUserCommand>
    {
        public EditUserCommandValidator()
        {
            RuleFor(x => x.UserName)
            .MaximumLength(60).WithMessage("The name cannot exceed 60 characters.");

            RuleFor(x => x.Gender)
            .Must(IsValid).WithMessage("Invalid gender.");
        }
        private bool IsValid(string? value)
        {
            return value == null || value == "M" || value == "F";
        }
    }
}
