﻿using BafMap.Domain.Entities;
using BafMap.Infrastructure.Persistence;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.ChangeTracking;
using Microsoft.Extensions.Logging;
using System.Linq.Expressions;

namespace BafMap.Services.Commands.EditUser
{
    public sealed class EditUserCommandHandler(BafMapContext ctx, ILoggerFactory factory) : IRequestHandler<EditUserCommand, Guid?>
    {
        private readonly ILogger _logger = factory.CreateLogger("UpdateUser");
        private readonly BafMapContext _ctx = ctx;

        public async Task<Guid?> Handle(EditUserCommand request, CancellationToken cancellationToken)
        {
            if (request == null || string.IsNullOrWhiteSpace(request.PhoneNumber))
            {
                _logger.LogError("{Time}: Error while updating user => AccountType specified not exists.", DateTime.UtcNow);
                return null;
            }

            using var trs = await _ctx.Database.BeginTransactionAsync(cancellationToken);
            try
            {
                var UserDb = await _ctx.Users.SingleOrDefaultAsync(u => u.PhoneNumber == request.PhoneNumber);
                if (UserDb == null)
                {
                    _logger.LogError("{Time}: Error while updating user => Not found", DateTime.UtcNow);
                    return null;
                }
                else if (request.Version != UserDb.Version)
                {
                    _logger.LogError("{0}: Error while updating user {1} => Conflict version", DateTime.UtcNow, request.PhoneNumber);
                    return null;
                }
                else
                {
                    // On désactive temporairement pour une meilleure perf.
                    _ctx.ChangeTracker.AutoDetectChangesEnabled = false;

                    var entry = _ctx.Entry(UserDb);

                    // On update intelligemment champ par champ.
                    UpdateStringIfChanged(entry, p => p.UserName, request.UserName);
                    UpdateStringIfChanged(entry, p => p.Gender, request.Gender);

                    UserDb.Version++;
                    UserDb.LastModified = DateTimeOffset.UtcNow;
                    _ctx.Entry(UserDb).Property(p => p.Version).IsModified = true;
                    _ctx.Entry(UserDb).Property(p => p.LastModified).IsModified = true;

                    _ctx.ChangeTracker.DetectChanges();
                    await _ctx.SaveChangesAsync(cancellationToken);
                    await trs.CommitAsync(cancellationToken);
                    return UserDb.Id;
                }
            }
            catch (Exception ex)
            {
                await trs.RollbackAsync();
                _logger.LogError("{Time}: Error while creating a new user/role => {Er}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }

        private void UpdateStringIfChanged<T>(EntityEntry<User> entity, Expression<Func<User, T>> property, T newValue)
        {
            var prop = entity.Property(property);
            var current = prop.CurrentValue;

            if (newValue != null && !EqualityComparer<T>.Default.Equals(current, newValue))
            {
                prop.CurrentValue = newValue;
                prop.IsModified = true;
            }
        }
    }
}
