﻿using MediatR;

namespace BafMap.Services.Commands.EditUser
{
    public record EditUserCommand(
        string PhoneNumber,
        string? UserName,
        string? Gender,
        int Version
        ) : IRequest<Guid?>;
}
