﻿using BafMap.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Commands.AddUserToRole
{
    public sealed class AddUserToRoleCommandHandler(UserManager<User> UserManager, ILoggerFactory factory) : IRequestHandler<AddUserToRoleCommand, bool>
    {
        private readonly ILogger _logger = factory.CreateLogger("AddUserToRole");
        private readonly UserManager<User> _UserManager = UserManager;

        public async Task<bool> Handle(AddUserToRoleCommand request, CancellationToken cancellationToken)
        {
            try
            {
                var User = await _UserManager.Users.SingleOrDefaultAsync(u => u.PhoneNumber == request.PhoneNumber);
                if (User == null)
                {
                    _logger.LogError("{Time}: User with Phonenumber '{phonenumber}' do not exists", DateTime.UtcNow, request.PhoneNumber);
                    return true;
                }

                var result = await _UserManager.AddToRoleAsync(User, request.RoleName);
                if (result.Succeeded)
                    return true;
                else
                {
                    foreach (var er in result.Errors)
                    {
                        _logger.LogError("{Time}: Model State Error while attempting to create a new role => {Er}", DateTime.UtcNow, er.Description);
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: AddUserToRoleError : {message}", DateTime.UtcNow, ex.Message);
                return false;
            }
        }
    }
}
