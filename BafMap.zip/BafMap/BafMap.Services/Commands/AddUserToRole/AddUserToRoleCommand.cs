﻿using MediatR;

namespace BafMap.Services.Commands.AddUserToRole
{
    public record AddUserToRoleCommand(string PhoneNumber, string RoleName) : IRequest<bool>;
}
