﻿using BafMap.Domain.Entities;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.Extensions.Logging;
using Microsoft.EntityFrameworkCore;

namespace BafMap.Services.Commands.ConfirmPassword
{
    public sealed class ConfirmPasswordCommandHandler : IRequestHandler<ConfirmPasswordCommand, bool>
    {
        private readonly ILogger _logger;
        private readonly UserManager<User> _UserManager;

        public ConfirmPasswordCommandHandler(UserManager<User> UserManager, ILoggerFactory factory)
        {
            _UserManager = UserManager;
            _logger = factory.CreateLogger("ConfirmPassword");
        }

        public async Task<bool> Handle(ConfirmPasswordCommand request, CancellationToken cancellationToken)
        {
            var User = await _UserManager.Users.FirstOrDefaultAsync(c => c.PhoneNumber == request.PhoneNumber);
            if (User == null)
            {
                _logger.LogError("{Time}: User with PhoneNumber = {phoneNumber} not found", DateTime.UtcNow, request.PhoneNumber);
                return false;
            }

            var isValidToken = await _UserManager.VerifyChangePhoneNumberTokenAsync(User, request.PinCode, request.PhoneNumber);
            if (isValidToken)
            {
                var hashPassword = _UserManager.PasswordHasher.HashPassword(User, request.NewPassword);
                User.PasswordHash = hashPassword;
                await _UserManager.UpdateAsync(User);
                return true;
            }
            else
            {
                _logger.LogError("{Time}: Verifying phoneNumber with code '{code}' was not be done", DateTime.UtcNow, request.PinCode);
                return false;
            }
        }
    }
}
