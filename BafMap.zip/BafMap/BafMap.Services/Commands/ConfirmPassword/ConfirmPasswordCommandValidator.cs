﻿using FluentValidation;

namespace BafMap.Services.Commands.ConfirmPassword
{
    public class ConfirmPasswordCommandValidator : AbstractValidator<ConfirmPasswordCommand>
    {
        public ConfirmPasswordCommandValidator()
        {
            RuleFor(x => x.PinCode)
            .NotEmpty().WithMessage("The PIN code is required.")
            .MinimumLength(4).WithMessage("The PIN code must be at least of length 4.");

            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Phonenumber is required.");

            RuleFor(x => x.NewPassword)
            .NotEmpty().WithMessage("The new password is required.")
            .MinimumLength(8).WithMessage("new Password must be at least of length 8")
            .Matches(@"[0-9]").WithMessage("new Password must contain at least one digit")
            .Matches(@"[A-Z]").WithMessage("new Password must contain at least one capital letter")
            .Matches(@"[a-z]").WithMessage("new Password must contain at least one lowercase letter"); ;
        }
    }
}
