﻿using MediatR;

namespace BafMap.Services.Commands.ConfirmPassword
{
    public record ConfirmPasswordCommand(
        string PhoneNumber,
        string PinCode,
        string NewPassword
        ) : IRequest<bool>;
}
