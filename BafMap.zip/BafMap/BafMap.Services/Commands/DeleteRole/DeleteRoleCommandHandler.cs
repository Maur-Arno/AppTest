﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using BafMap.Domain.Entities;
using BafMap.Infrastructure.Persistence;

namespace BafMap.Services.Commands.DeleteRole
{
    public sealed class DeleteRoleCommandHandler : IRequestHandler<DeleteRoleCommand, bool>
    {
        private readonly ILogger _logger;
        private readonly RoleManager<Role> _roleManager;
        private readonly BafMapContext _ctx;

        public DeleteRoleCommandHandler(RoleManager<Role> roleManager, BafMapContext context, ILoggerFactory factory)
        {
            _roleManager = roleManager;
            _ctx = context;
            _logger = factory.CreateLogger("DeleteRole");
        }

        public async Task<bool> Handle(DeleteRoleCommand request, CancellationToken cancellationToken)
        {
            var role = await _roleManager.Roles.FirstOrDefaultAsync(r => r.Name == request.RoleName, cancellationToken);
            if (role == null)
            {
                _logger.LogError($"The role with Name '{request.RoleName}' was not found.");
                return false;
            }

            if (await _ctx.UserRoles.AnyAsync(ur => ur.RoleId == role.Id))
            {
                _logger.LogError($"User with the role name '{request.RoleName}' exists.");
                return false;
            }

            try
            {
                await _roleManager.DeleteAsync(role);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: DeleteRoleError : {body}", DateTime.Now, ex.Message);
                return false;
            }
        }
    }
}
