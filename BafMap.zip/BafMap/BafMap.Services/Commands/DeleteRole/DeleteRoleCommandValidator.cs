﻿using FluentValidation;

namespace BafMap.Services.Commands.DeleteRole
{
    public class DeleteRoleCommandValidator : AbstractValidator<DeleteRoleCommand>
    {
        public DeleteRoleCommandValidator()
        {
            RuleFor(x => x.RoleName)
            .NotEmpty().WithMessage("The name is required.");
        }
    }
}
