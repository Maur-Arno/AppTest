﻿using MediatR;

namespace BafMap.Services.Commands.DeleteRole
{
    public record DeleteRoleCommand(string RoleName) : IRequest<bool>;
}
