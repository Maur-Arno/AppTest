﻿namespace BafMap.Services.Common
{
    public static class Utilities
    {  
        private static readonly string[] orangeNbrs = ["655", "656", "657", "658", "659", "69"];
        private static readonly string[] mtnNbrs = ["650", "651", "652", "653", "654", "670", "671", "672", "673", "674", "675", "676", "677", "678", "679", "68"];
        private static readonly string[] countriesCodes = ["221", "223", "225", "226", "227", "228", "229", "235", "236", "237", "240", "241", "242", "245"];

        public static bool IsValidOrangeNbr(string value)
        {
            foreach (string orange in orangeNbrs)
            {
                if (value.Trim().StartsWith(orange)) return true;
            }
            return false;
        }

        public static bool IsValidMtnNbr(string value)
        {
            foreach (string mtn in mtnNbrs)
            {
                if (value.Trim().StartsWith(mtn)) return true;
            }
            return false;
        }

        public static int GetOperatorType(string number)
        {
            if (IsValidOrangeNbr(number))
                return 6;
            else if (IsValidMtnNbr(number))
                return 7;
            else
                return 0;
        }

        public static bool IsValidCountryCode(string countryCode)
        {
            foreach (var code in countriesCodes)
            {
                if (string.Equals(countryCode, code))
                    return true;
            }
            return false;
        }
    }
}
