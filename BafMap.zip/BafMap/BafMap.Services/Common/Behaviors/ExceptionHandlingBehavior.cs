﻿using MediatR;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Common.Behaviors
{
    /// <summary>
    /// Activation automatique de la gestion d'exception grace au pipeline
    /// </summary>
    /// <typeparam name="TRequest"></typeparam>
    /// <typeparam name="TResponse"></typeparam>
    public class ExceptionHandlingBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : IRequest<TResponse>
    {
        private readonly ILogger<ExceptionHandlingBehavior<TRequest, TResponse>> _logger;

        public ExceptionHandlingBehavior(ILogger<ExceptionHandlingBehavior<TRequest, TResponse>> logger)
        {
            _logger = logger;
        }

        public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            try
            {
                return await next();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, "The request '{Request}' failed at {DateTime} with exception '{Message}'", typeof(TRequest).Name, DateTime.UtcNow, ex.Message);
                throw new ApplicationException($"An error occurred while processing {typeof(TRequest).Name}");
            }
        }
    }
}
