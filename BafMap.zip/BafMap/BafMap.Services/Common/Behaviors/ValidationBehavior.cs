﻿using FluentValidation;
using MediatR;

namespace BafMap.Services.Common.Behaviors
{
    /// <summary>
    /// Activation automatique de la validation grace au pipeline :
    /// Intercepte toutes les commandes / queries et exécute la validation avant la prise en charge par le Handler
    /// </summary>
    /// <typeparam name="TRequest"></typeparam>
    /// <typeparam name="TResponse"></typeparam>
    public class ValidationBehavior<TRequest, TResponse> : IPipelineBehavior<TRequest, TResponse> where TRequest : IRequest<TResponse>
    {
        private readonly IEnumerable<IValidator<TRequest>> _validators;

        public ValidationBehavior(IEnumerable<IValidator<TRequest>> validators)
            => _validators = validators;

        public async Task<TResponse> Handle(TRequest request, RequestHandlerDelegate<TResponse> next, CancellationToken cancellationToken)
        {
            if (_validators.Any())
            {
                var context = new ValidationContext<TRequest>(request);

                var validationResults = await Task.WhenAll(
                    _validators.Select(v => v.ValidateAsync(context, cancellationToken))
                    );

                var validationFailures = validationResults.SelectMany(result => result.Errors)
                                               .Where(f => f != null)
                                               .ToList();

                if (validationFailures.Count != 0)
                {
                    throw new ValidationException(validationFailures);
                }
            }

            return await next();
        }
    }
}
