﻿using BafMap.Services.Common.Behaviors;
using FluentValidation;
using MediatR;
using Microsoft.Extensions.DependencyInjection;

namespace BafMap.Services
{
    public static class ServicesDependencyInjection
    {
        public static IServiceCollection AddServicesDI(this IServiceCollection services)
        {
            services.AddMediatR(cfg =>
                cfg.RegisterServicesFromAssembly(typeof(ServicesDependencyInjection).Assembly));

            // Enregistrement auto des validateurs
            services.AddValidatorsFromAssembly(typeof(ServicesDependencyInjection).Assembly);

            // Enregistrement auto des pipelines
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ExceptionHandlingBehavior<,>));
            services.AddTransient(typeof(IPipelineBehavior<,>), typeof(ValidationBehavior<,>));

            // Enregistrement des services spécifiques
            services.AddScoped<ISmsService, SmsService>();

            return services;
        }
    }
}
