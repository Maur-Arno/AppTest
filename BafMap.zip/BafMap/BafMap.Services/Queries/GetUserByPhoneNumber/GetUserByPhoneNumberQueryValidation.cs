﻿using FluentValidation;

namespace BafMap.Services.Queries.GetUserByPhoneNumber
{
    public class GetUserByPhoneNumberQueryValidation : AbstractValidator<GetUserByPhoneNumberQuery>
    {
        public GetUserByPhoneNumberQueryValidation()
        {
            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Phonenumber is required.")
            .Matches(@"\d+").WithMessage("Not a phone number.")
            .MaximumLength(9).WithMessage("The phone number cannot exceed 9 characters.")
            .Must(IsValid).WithMessage("Must be Orange / Mtn number.");
        }

        private bool IsValid(string value)
        {
            return Common.Utilities.IsValidOrangeNbr(value) || Common.Utilities.IsValidMtnNbr(value);
        }
    }
}
