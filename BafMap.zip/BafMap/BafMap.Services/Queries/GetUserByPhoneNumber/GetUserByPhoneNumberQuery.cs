﻿using MediatR;
using BafMap.Domain.Entities;

namespace BafMap.Services.Queries.GetUserByPhoneNumber
{
    public record GetUserByPhoneNumberQuery(string PhoneNumber) : IRequest<User?>;
}
