﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using BafMap.Domain.Entities;

namespace BafMap.Services.Queries.GetUserByPhoneNumber
{
    public sealed class GetUserByPhoneNumberQueryHandler(UserManager<User> ProfileManager, ILoggerFactory factory) : IRequestHandler<GetUserByPhoneNumberQuery, User?>
    {
        private readonly ILogger _logger = factory.CreateLogger("GetUserByPhoneNumber");
        private readonly UserManager<User> _ProfileManager = ProfileManager;

        public async Task<User?> Handle(GetUserByPhoneNumberQuery request, CancellationToken cancellationToken)
        {
            try
            {
                return await _ProfileManager.Users.AsNoTracking().SingleOrDefaultAsync(u => u.PhoneNumber == request.PhoneNumber);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: GetUserByPhoneNumberError : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
