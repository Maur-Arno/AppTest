﻿using MediatR;
using BafMap.Services.DTOs;

namespace BafMap.Services.Queries.GetAllRoles
{
    public record GetAllRolesQuery() : IRequest<RoleDto[]?>;
}
