﻿using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using BafMap.Domain.Entities;
using BafMap.Services.DTOs;

namespace BafMap.Services.Queries.GetAllRoles
{
    public sealed class GetAllRolesQueryHandler : IRequestHandler<GetAllRolesQuery, RoleDto[]?>
    {
        private readonly ILogger _logger;
        private readonly RoleManager<Role> _roleManager;

        public GetAllRolesQueryHandler(RoleManager<Role> roleManager, ILoggerFactory factory)
        {
            _roleManager = roleManager;
            _logger = factory.CreateLogger("Roles");
        }

        public async Task<RoleDto[]?> Handle(GetAllRolesQuery request, CancellationToken cancellationToken)
        {
            try
            {
                return await _roleManager.Roles.AsNoTracking().Select(x => new RoleDto(x.Name!, x.Description!)).ToArrayAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: GetAllRolesError : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
