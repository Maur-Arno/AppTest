﻿using BafMap.Domain.Entities;
using MediatR;

namespace BafMap.Services.Queries.GetOfficialAddresses
{
    public record GetOfficialAddressesQuery(
        string City,
        string Quarter) : IRequest<List<Address>?>;
}
