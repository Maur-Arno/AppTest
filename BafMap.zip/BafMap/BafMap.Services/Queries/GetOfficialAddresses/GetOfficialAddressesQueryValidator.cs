﻿using FluentValidation;

namespace BafMap.Services.Queries.GetOfficialAddresses
{
    public class GetOfficialAddressesQueryValidator : AbstractValidator<GetOfficialAddressesQuery>
    {
        public GetOfficialAddressesQueryValidator()
        {
            RuleFor(x => x.City)
            .NotEmpty().WithMessage("The city is required.");

            RuleFor(x => x.Quarter)
            .NotEmpty().WithMessage("The quarter is required.");
        }
    }
}
