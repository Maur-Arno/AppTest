﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using MediatR;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Queries.GetOfficialAddresses
{
    public sealed class GetOfficialAddressesQueryHandler(ILocationValidationRepository LocationValidationRepository, ILoggerFactory factory) : IRequestHandler<GetOfficialAddressesQuery, List<Address>?>
    {
        private readonly ILogger _logger = factory.CreateLogger("GetOfficialAddresses");
        private readonly ILocationValidationRepository _locationValidationRepository = LocationValidationRepository;
        public async Task<List<Address>?> Handle(GetOfficialAddressesQuery request, CancellationToken cancellationToken)
        {
            try
            {
                return await _locationValidationRepository.GetAddressesAsync(request.City, request.Quarter);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: GetOfficialAddresses : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
