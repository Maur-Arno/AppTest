﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using MediatR;

namespace BafMap.Services.Queries.GetAddressesNearBy
{
    public sealed class GetAddressesNearByQueryHandler(ILocationValidationRepository LocationValidationRepository) : IRequestHandler<GetAddressesNearByQuery, List<Address>?>
    {
        private readonly ILocationValidationRepository _locationValidationRepository = LocationValidationRepository;
        public async Task<List<Address>?> Handle(GetAddressesNearByQuery request, CancellationToken cancellationToken)
            => await _locationValidationRepository.AddressesNearByAsync(request.Longitude, request.Latitude);
    }
}
