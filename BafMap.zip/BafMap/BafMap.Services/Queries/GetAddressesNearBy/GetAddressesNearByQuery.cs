﻿using BafMap.Domain.Entities;
using MediatR;

namespace BafMap.Services.Queries.GetAddressesNearBy
{
    public record GetAddressesNearByQuery(
        double Longitude,
        double Latitude
        ) : IRequest<List<Address>?>;
}
