﻿using MediatR;
using BafMap.Services.DTOs;

namespace BafMap.Services.Queries.GetUserByName
{
    public record GetUserByNameQuery(
        string UserName,
        string[]? Cities,
        string[]? Occupations) : IRequest<UserDto?>;
}
