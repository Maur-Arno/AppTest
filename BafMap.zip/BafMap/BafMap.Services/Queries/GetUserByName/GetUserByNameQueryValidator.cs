﻿using FluentValidation;

namespace BafMap.Services.Queries.GetUserByName
{
    public class GetUserByNameQueryValidator : AbstractValidator<GetUserByNameQuery>
    {
        public GetUserByNameQueryValidator()
        {
            RuleFor(x => x.UserName)
            .NotEmpty().WithMessage("The UserName is required.")
            .MinimumLength(3).WithMessage("The UserName cannot be less than 3 characters.");
        }
    }
}
