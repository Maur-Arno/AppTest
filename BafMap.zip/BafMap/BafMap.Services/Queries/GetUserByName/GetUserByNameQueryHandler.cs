﻿using BafMap.Domain.Entities;
using BafMap.Services.DTOs;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Queries.GetUserByName
{
    public sealed class GetUserByNameQueryHandler : IRequestHandler<GetUserByNameQuery, UserDto?>
    {
        private readonly ILogger _logger;
        private readonly UserManager<User> _ProfileManager;

        public GetUserByNameQueryHandler(UserManager<User> profileManager, ILoggerFactory factory)
        {
            _ProfileManager = profileManager;
            _logger = factory.CreateLogger("GetUserByName");
        }

        public async Task<UserDto?> Handle(GetUserByNameQuery request, CancellationToken cancellationToken)
        {
            try
            {
                return await _ProfileManager.Users.AsNoTracking().Where(p => 
                        p.UserName!.ToLower().Contains(request.UserName.ToLower())
                     )
                     .Select(user => new UserDto(user.UserName!, user.Gender!, user.PhoneNumber!, user.Version))
                     .FirstOrDefaultAsync(cancellationToken);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: GetUserByNameError : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
