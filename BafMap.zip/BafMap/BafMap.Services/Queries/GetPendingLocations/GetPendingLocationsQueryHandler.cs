﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using MediatR;

namespace BafMap.Services.Queries.GetPendingLocations
{
    public sealed class GetPendingLocationsQueryHandler(ILocationReadRepository locationReadRepository) : IRequestHandler<GetPendingLocationsQuery, List<LocationRequest>?>
    {
        private readonly ILocationReadRepository _locationReadRepository = locationReadRepository;
        public async Task<List<LocationRequest>?> Handle(GetPendingLocationsQuery request, CancellationToken cancellationToken)
          => await _locationReadRepository.GetPendingLocationsAsync(request.City);
    }
}
