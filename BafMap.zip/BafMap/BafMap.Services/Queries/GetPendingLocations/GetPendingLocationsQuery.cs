﻿using BafMap.Domain.Entities;
using MediatR;

namespace BafMap.Services.Queries.GetPendingLocations
{
    public record GetPendingLocationsQuery(string City) : IRequest<List<LocationRequest>?>;
}
