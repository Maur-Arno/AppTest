﻿using MediatR;
using BafMap.Services.DTOs;

namespace BafMap.Services.Queries.GetUsersInRole
{
    public record GetUsersInRoleQuery(string RoleName) : IRequest<ManageUsersDto?>;
}
