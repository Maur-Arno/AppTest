﻿using BafMap.Infrastructure.Persistence;
using BafMap.Services.DTOs;
using MediatR;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Services.Queries.GetUsersInRole
{
    public sealed class GetUsersInRoleQueryHandler(BafMapContext context, ILoggerFactory factory) : IRequestHandler<GetUsersInRoleQuery, ManageUsersDto?>
    {
        private readonly ILogger _logger = factory.CreateLogger("GetUsersInRole");
        private readonly BafMapContext _ctx = context;

        public async Task<ManageUsersDto?> Handle(GetUsersInRoleQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var usersInRole = await (
                    from user in _ctx.Users
                    join userRole in _ctx.UserRoles on user.Id equals userRole.UserId
                    join role in _ctx.Roles on userRole.RoleId equals role.Id
                    where role.Name == request.RoleName
                    select new UserRoleDto(user.PhoneNumber!, user.UserName!)
                ).ToArrayAsync(cancellationToken);

                var usersOutOfRole = await (
                    from user in _ctx.Users
                    join userRole in _ctx.UserRoles on user.Id equals userRole.UserId
                    join role in _ctx.Roles on userRole.RoleId equals role.Id
                    where role.Name != request.RoleName
                    select new UserRoleDto(user.PhoneNumber!, user.UserName!)
                ).ToArrayAsync(cancellationToken);

                return new ManageUsersDto(usersInRole, usersOutOfRole);
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: GetUsersInRoleError : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
