﻿using MediatR;
using BafMap.Services.DTOs;

namespace BafMap.Services.Queries.LogInUser
{
    public record GetUserCredentialQuery(
        string PhoneNumber,
        string Password,
        string DeviceId
        ) : IRequest<UserCredentialDto?>;
}
