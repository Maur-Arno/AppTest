﻿using BafMap.Domain.Entities;
using BafMap.Services.DTOs;
using MediatR;
using Microsoft.AspNetCore.Identity;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.Logging;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.IdentityModel.Tokens;
using System.Security.Claims;
using System.Text;

namespace BafMap.Services.Queries.LogInUser
{
    public sealed class GetUserCredentialQueryHandler(UserManager<User> ProfileManager, ILoggerFactory factory, IConfiguration configuration)
        : IRequestHandler<GetUserCredentialQuery, UserCredentialDto?>
    {
        private readonly ILogger _logger = factory.CreateLogger("LogInUser");
        private readonly UserManager<User> _ProfileManager = ProfileManager;
        public readonly IConfiguration _configuration = configuration;
        public async Task<UserCredentialDto?> Handle(GetUserCredentialQuery request, CancellationToken cancellationToken)
        {
            try
            {
                var Profile = await _ProfileManager.Users.SingleOrDefaultAsync(c => c.PhoneNumber == request.PhoneNumber, cancellationToken);
                if (Profile == null)
                {
                    _logger.LogError("{Time}: User with PhoneNumber '{phoneNumber}' not found", DateTime.UtcNow, request.PhoneNumber);
                    return null;
                }
                else if (!Profile.PhoneNumberConfirmed)
                {
                    _logger.LogError("{Time}: PhoneNumber '{phoneNumber}' is not confirmed yet.", DateTime.UtcNow, request.PhoneNumber);
                    return null;
                }
                else if (!(await _ProfileManager.CheckPasswordAsync(Profile, request.Password)))
                {
                    _logger.LogError("{Time}: User exists but bad password.", DateTime.UtcNow);
                    return null;
                }
                else
                {
                    var roles = await _ProfileManager.GetRolesAsync(Profile);

                    var authClaims = new Dictionary<string, object>
                {
                    { ClaimTypes.Name, Profile.UserName! },
                    { ClaimTypes.MobilePhone, Profile.PhoneNumber! }
                };

                    foreach (var role in roles)
                    {
                        authClaims.Add(ClaimTypes.Role, role);
                    }

                    var authSigningKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_configuration["Jwt:key"]!));

                    var token = new SecurityTokenDescriptor
                    {
                        Issuer = _configuration["Jwt:Issuer"],
                        Audience = _configuration["Jwt:Audience"],
                        Expires = DateTime.Now.AddHours(1),
                        Claims = authClaims,
                        SigningCredentials = new SigningCredentials(authSigningKey, SecurityAlgorithms.HmacSha256Signature)
                    };

                    return new UserCredentialDto(Profile!.UserName!, new JsonWebTokenHandler().CreateToken(token), token.Expires);
                }
            }
            catch (Exception ex)
            {
                _logger.LogError("{Time}: LogInUserError : {message}", DateTime.UtcNow, ex.Message);
                return null;
            }
        }
    }
}
