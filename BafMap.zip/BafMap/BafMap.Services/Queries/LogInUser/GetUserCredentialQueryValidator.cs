﻿using FluentValidation;

namespace BafMap.Services.Queries.LogInUser
{
    public class GetUserCredentialQueryValidator : AbstractValidator<GetUserCredentialQuery>
    {
        public GetUserCredentialQueryValidator()
        {
            RuleFor(x => x.PhoneNumber)
            .NotEmpty().WithMessage("Phonenumber is required.")
            .Matches(@"\d+").WithMessage("Not a phone number.")
            .MaximumLength(9).WithMessage("The phone number cannot exceed 9 characters.")
            .Must(IsValid).WithMessage("Must be Orange / Mtn number.");
            
            RuleFor(x => x.Password)
            .NotEmpty().WithMessage("Password is required.")
            .MinimumLength(8).WithMessage("Password must be at least of length 8")
            .Matches(@"[0-9]").WithMessage("Password must contain at least one digit")
            .Matches(@"[A-Z]").WithMessage("Password must contain at least one capital letter")
            .Matches(@"[a-z]").WithMessage("Password must contain at least one lowercase letter");

            RuleFor(x => x.DeviceId)
            .NotEmpty().WithMessage("Device Id is required.");
        }

        private bool IsValid(string value)
        {
            return Common.Utilities.IsValidOrangeNbr(value) || Common.Utilities.IsValidMtnNbr(value);
        }
    }
}
