﻿using Microsoft.Extensions.Caching.Memory;

namespace BafMap.Services
{
    public class SmsService(IMemoryCache cache, HttpClient http) : ISmsService
    {

        private readonly IMemoryCache _cache = cache;
        private readonly HttpClient _http = http;
        public bool CanSendOtp(string phoneNumber)
        {
            var key = $"otp_{phoneNumber}";

            if (_cache.TryGetValue(key, out int count))
            {
                if (count >= 2) return false;  // 2 sms / heure / numéro (pour limiter le cout)

                _cache.Set(key, count++, TimeSpan.FromHours(1));
                return true;
            }

            _cache.Set(key, 1, TimeSpan.FromHours(1));
            return true;
        }

        public async Task<bool> SendSmsAsync(string phoneNumber, string token)
        {
            return true;
        }
    }
}
