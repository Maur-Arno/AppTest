﻿using Microsoft.AspNetCore.Identity;
using System.ComponentModel.DataAnnotations;

namespace BafMap.Domain.Entities
{
    public class User : IdentityUser<Guid>
    {
        public string? Gender { get; set; }
        [Required]
        public int Version { get; set; }
        [Required]
        public DateTime CreatedAt { get; set; }
        public DateTimeOffset LastModified { get; set; } = DateTimeOffset.UtcNow;

        public virtual ICollection<IdentityUserClaim<Guid>> Claims { get; set; } = null!;
        public virtual ICollection<IdentityUserLogin<Guid>> Logins { get; set; } = null!;
        public virtual ICollection<IdentityUserToken<Guid>> Tokens { get; set; } = null!;
        public virtual ICollection<UserRole> Roles { get; set; } = null!;
        public virtual ICollection<Address>? Addresses { get; set; }
    }
}
