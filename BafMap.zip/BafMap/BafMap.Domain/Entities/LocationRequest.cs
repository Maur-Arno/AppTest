﻿using NetTopologySuite.Geometries;

namespace BafMap.Domain.Entities
{
    /// <summary>
    /// Demande d'adressage (qui doit etre validée par un agent de la mairie).
    /// </summary>
    public class LocationRequest
    {
        public Guid Id { get; private set; }
        public string Reference { get; private set; } = null!;
        public string LocalName { get; private set; } = null!;
        public string City { get; private set; } = null!;
        public string Quarter { get; private set; } = null!;
        public LocationType Category { get; private set; }
        public string GooglePlusCode { get; private set; } = null!;
        public Point Position { get; private set; } = null!;
        public string Description { get; private set; } = null!;
        public string PhotoUrl { get; private set; } = null!;
        public LocationStatus Status { get; private set; }

        public LocationRequest(string reference, string localName, string city, string quarter, LocationType category, string googlePlusCode, Point position, string description, string photoUrl)
        {
            Reference = reference;
            LocalName = localName;
            City = city;
            Quarter = quarter;
            Category = category;
            GooglePlusCode = googlePlusCode;
            Position = position;
            Description = description;
            PhotoUrl = photoUrl;
            Status = LocationStatus.Pending;
        }
    }
}
