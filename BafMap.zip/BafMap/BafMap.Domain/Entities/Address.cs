﻿using NetTopologySuite.Geometries;

namespace BafMap.Domain.Entities
{
    /// <summary>
    /// Adresse officielle (validée par la mairie).
    /// </summary>
    public class Address
    {
        public Guid Id { get; private set; }
        public string Reference { get; private set; } = null!;
        public string LocalName { get; private set; } = null!;
        public string City { get; private set; } = null!;
        public string Quarter { get; private set; } = null!;
        public LocationType Category { get; private set; }
        public string GooglePlusCode { get; private set; } = null!;
        public Point Position { get; private set; } = null!;
        public string Description { get; private set; } = null!;
        public string PhotoUrl { get; private set; } = null!;
        public DateTime CreatedAt { get; private set; }
        //Navigation properties
        public Guid? UserId { get; set; }
        public virtual User? User { get; set; }

        public Address(string reference, string localName, string city, string quarter, LocationType category, string googlePlusCode, Point position, string description, string photoUrl)
        {
            Reference = reference;
            LocalName = localName;
            City = city;
            Quarter = quarter;
            Category = category;
            GooglePlusCode = googlePlusCode;
            Position = position;
            Description = description;
            PhotoUrl = photoUrl;
            CreatedAt = DateTime.UtcNow;
        }
    }
}
