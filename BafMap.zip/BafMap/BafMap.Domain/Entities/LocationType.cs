﻿namespace BafMap.Domain.Entities
{
    /// <summary>
    /// Type de bâtiment.
    /// </summary>
    public enum LocationType
    {
        // Résidence
        R,
        // Commerce
        C,
        // Ecole
        E,
        // Hopital
        H,
        // Administration
        A
    }
}
