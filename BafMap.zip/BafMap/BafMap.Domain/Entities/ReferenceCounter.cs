﻿using System.ComponentModel.DataAnnotations;

namespace BafMap.Domain.Entities
{
    public class ReferenceCounter
    {
        public Guid Id { get; set; }
        [StringLength(3, ErrorMessage = "Trigramme attendu.")]
        public string City { get; private set; } = null!;
        [StringLength(3, ErrorMessage = "Trigramme attendu.")]
        public string Quarter { get; private set; } = null!;
        public char Category { get; private set; }
        public uint NextValue { get; private set; }

        public ReferenceCounter(string city, string quarter, char category, uint nextValue)
        {
            City = city;
            Quarter = quarter;
            Category = category;
            NextValue = nextValue;
        }
    }
}
