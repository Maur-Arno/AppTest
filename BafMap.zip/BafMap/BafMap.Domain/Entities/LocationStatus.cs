﻿namespace BafMap.Domain.Entities
{
    /// <summary>
    /// Etat de création.
    /// </summary>
    public enum LocationStatus
    {
        Pending,
        Approved,
        Rejected
    }
}
