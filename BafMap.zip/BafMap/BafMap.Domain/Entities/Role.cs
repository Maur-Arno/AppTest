﻿using Microsoft.AspNetCore.Identity;

namespace BafMap.Domain.Entities
{
    public class Role : IdentityRole<Guid>
    {
        public string Key { get; set; } = null!;
        public string? Description { get; set; }
        // navigation property
        public virtual ICollection<UserRole> Users { get; set; } = null!;
        public virtual ICollection<IdentityRoleClaim<Guid>> Claims { get; set; } = null!;
    }
}