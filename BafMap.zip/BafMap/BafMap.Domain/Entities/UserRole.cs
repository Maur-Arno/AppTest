﻿using Microsoft.AspNetCore.Identity;

namespace BafMap.Domain.Entities
{
    public class UserRole : IdentityUserRole<Guid>
    {
        public new Guid? UserId { get; set; }
        public new Guid? RoleId { get; set; }
        public virtual User User { get; set; } = null!;
        public virtual Role Role { get; set; } = null!;
    }
}