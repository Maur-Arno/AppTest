﻿using BafMap.Domain.Entities;

namespace BafMap.Domain.Ports
{
    public interface ILocationValidationRepository
    {
        Task<bool> RegisterReference(string city, string quarter, char category, uint referenceCode);
        Task<List<Address>?> GetAddressesAsync(string city, string quarter);
        Task<List<Address>?> AddressesNearByAsync(double Longitude, double Latitude);
        Task<bool> AddAddressAsync(Address address);
        Task<bool> AddTempAddressAsync(LocationRequest tempAddress);
        bool UpdateAddress(Address address);
        bool DeleteAddress(Address address);
    }
}
