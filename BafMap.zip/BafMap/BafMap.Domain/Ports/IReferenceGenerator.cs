﻿namespace BafMap.Domain.Ports
{
    public interface IReferenceGenerator
    {
        Task<string> GenerateAsync(string cityCode, string quarterCode, string category, CancellationToken cancellationToken);
    }
}
