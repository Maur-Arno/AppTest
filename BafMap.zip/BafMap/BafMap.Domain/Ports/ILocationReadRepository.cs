﻿using BafMap.Domain.Entities;

namespace BafMap.Domain.Ports
{
    public interface ILocationReadRepository
    {
        Task<bool> ExistsNearByAsync(
            string Name,
            LocationType Category,
            double Longitude,
            double Latitude,
            double RadiusInMeters,
            CancellationToken cancellationToken);

        Task<bool> ExistsAddressReferenceAsync(string reference);
        Task<Address?> GetAddressByReferenceAsync(string reference);
        Task<List<LocationRequest>?> GetPendingLocationsAsync(string city);
    }
}
