﻿namespace BafMap.Client.DTOs
{
    public enum RequestStatus
    {
        None,
        Pending,
        Validated,
        Rejected,
        Merged
    }
}
