﻿namespace BafMap.Client.DTOs
{
    public class RoleDto
    {
        public string Key { get; set; } = null!;
        public string Name { get; set; } = null!;
        public string Description { get; set; } = null!;
        public string Icon { get; set; } = null!;
        public uint UserCount { get; set; }
    }
}
