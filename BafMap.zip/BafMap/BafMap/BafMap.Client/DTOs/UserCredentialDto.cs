﻿namespace BafMap.Client.DTOs
{
    public record UserCredentialDto(
        string UserName,
        string Token,
        DateTime? Expires
        );
}
