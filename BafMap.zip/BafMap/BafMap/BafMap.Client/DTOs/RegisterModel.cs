﻿using System.ComponentModel.DataAnnotations;

namespace BafMap.Client.DTOs
{
    public sealed class RegisterModel
    {
        [Required(ErrorMessage = "Le pseudonyme est obligatoire.")]
        public string Pseudo { get; set; } = string.Empty;

        [Required(ErrorMessage = "Le téléphone est obligatoire.")]
        public string Identifier { get; set; } = string.Empty;


        [Required(ErrorMessage = "Le mot de passe est obligatoire.")]
        [MinLength(6, ErrorMessage = "Le mot de passe doit contenir au moins 6 caractères.")]
        public string Password { get; set; } = string.Empty;

        //[Compare(Password, ErrorMessage = "Le mot de passe est obligatoire.")]
        [Required(ErrorMessage = "Le mot de passe est obligatoire.")]
        [MinLength(6, ErrorMessage = "Le mot de passe doit contenir au moins 6 caractères.")]
        public string ConfirmPassword { get; set; } = string.Empty;
    }
}
