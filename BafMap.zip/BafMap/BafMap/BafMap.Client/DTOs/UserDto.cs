﻿namespace BafMap.Client.DTOs
{
    public record UserDto(
        string UserName,
        string? Gender,
        string PhoneNumber
    );
}
