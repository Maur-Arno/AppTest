﻿namespace BafMap.Client.DTOs
{
    public record Metadatas(string Key, string Value);
}
