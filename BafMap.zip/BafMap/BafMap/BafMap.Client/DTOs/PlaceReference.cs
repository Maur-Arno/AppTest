﻿namespace BafMap.Client.DTOs
{
    public sealed class PlaceReference
    {
        public string Reference { get; set; } = null!;
        public string Name { get; set; } = string.Empty;
        public string District { get; set; } = string.Empty;
        public DateTime CreatedAt { get; set; }
    }
}
