﻿namespace BafMap.Client.DTOs
{
    public record LoginDto(
        string PhoneNumber,
        string Password);
}
