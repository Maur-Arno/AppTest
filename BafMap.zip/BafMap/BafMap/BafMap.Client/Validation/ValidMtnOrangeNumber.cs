﻿using System.ComponentModel.DataAnnotations;

namespace BafMap.Client.Validation
{
    public class ValidMtnOrangeNumber : ValidationAttribute
    {
        private readonly string[] orangeNbrs = ["655", "656", "657", "658", "659", "69"];
        private readonly string[] mtnNbrs = ["650", "651", "652", "653", "654", "670", "671", "672", "673", "674", "675", "676", "677", "678", "679", "68"];
        private bool isOrange, isMtn;

        public override bool IsValid(object? value)
        {
            isOrange = isMtn = false;

            foreach (string orange in orangeNbrs)
            {
                if (value != null && value.ToString()!.Trim().StartsWith(orange)) isOrange = true;
            }
            foreach (string mtn in mtnNbrs)
            {
                if (value != null && value.ToString()!.Trim().StartsWith(mtn)) isMtn = true;
            }

            return isOrange || isMtn;
        }
    }
}
