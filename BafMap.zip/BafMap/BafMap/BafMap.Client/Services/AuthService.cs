﻿using BafMap.Shared.DTO;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.JSInterop;
using System.Net.Http.Headers;
using System.Net.Http.Json;
using System.Text.Json;

namespace BafMap.Client.AuthenticationStateProviders
{
    public class AuthService : IAuthService
    {
        private readonly HttpClient _httpClient;
        private readonly IJSRuntime _JSRuntime;
        private readonly AuthenticationStateProvider _authenticationStateProvider;
        private readonly ILocalStorageService _localStorage;

        public AuthService(HttpClient httpClient, AuthenticationStateProvider authenticationStateProvider,
                           ILocalStorageService localStorage, IJSRuntime JSRuntime)
        {
            _httpClient = httpClient;
            _JSRuntime = JSRuntime;
            _authenticationStateProvider = authenticationStateProvider;
            _localStorage = localStorage;
        }

        public async Task<CongelCamModel<LoginResult>> Login(LoginModel loginModel)
        {
            var response = await _httpClient.PostAsJsonAsync("api/Authentication/login", loginModel);
            var loginResult = await response.Content.ReadFromJsonAsync<CongelCamModel<LoginResult>>(new JsonSerializerOptions { PropertyNameCaseInsensitive = true });

            if (loginResult.Successful)
            {
                await _localStorage.SetItemAsync("authToken", loginResult.Data?.Token);
                ((TokenAuthenticationStateProvider)_authenticationStateProvider).MarkUserAsAuthenticated(loginResult.Data?.Token);
                _httpClient.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", loginResult.Data?.Token);

                return loginResult;
            }

            return loginResult;
        }

        public async Task Logout()
        {
            await _localStorage.RemoveItemAsync("authToken");
            ((TokenAuthenticationStateProvider)_authenticationStateProvider).MarkUserAsLoggedOut();
            _httpClient.DefaultRequestHeaders.Authorization = null;
        }

        public async Task ShowHidePassword(string id_password)
        {
            await _JSRuntime.InvokeAsync<object>("showHidePassword", id_password);
        }

        public async Task Logout()
        {
            await _localStorage.RemoveItemAsync("authToken");
            ((TokenAuthenticationStateProvider)_authenticationStateProvider).MarkUserAsLoggedOut();
            _httpClient.DefaultRequestHeaders.Authorization = null;
        }
    }
}
