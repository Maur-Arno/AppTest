﻿using BafMap.Client.DTOs;

namespace BafMap.Client.Services
{
    public interface ILocalDbProfileService
    {
        Task SaveLocalChangesAsync(ProfileDto data, bool pending = true);
        Task DeleteAsync(string id);
        Task<List<ProfileDto>?> GetAllAsync();
        Task<ProfileDto?> GetAsync(string id);
        Task<List<ProfileDto>?> GetLocalPendingChangesAsync();
        Task ApplyServerPullChangesAsync(string id);
        Task<string?> GetLastSyncTokenAsync();
        Task SetLastSyncTokenAsync(string token);
    }
}
