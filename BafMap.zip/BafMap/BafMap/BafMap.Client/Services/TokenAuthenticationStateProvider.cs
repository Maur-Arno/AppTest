﻿using BafMap.Client.DTOs;
using Microsoft.AspNetCore.Components.Authorization;
using Microsoft.IdentityModel.JsonWebTokens;
using Microsoft.JSInterop;
using System.Net.Http.Headers;
using System.Security.Claims;

namespace BafMap.Client.AuthenticationStateProviders
{
    public class TokenAuthenticationStateProvider(HttpClient httpClient, IJSRuntime js) : AuthenticationStateProvider
    {
        private readonly HttpClient http = httpClient;
        private readonly IJSRuntime _js = js;

        // determine the current users authentication state
        public override async Task<AuthenticationState> GetAuthenticationStateAsync()
        {
            var module = await _js.InvokeAsync<IJSObjectReference>("import", "./indexedDb.js");
            var SavedToken = await module.InvokeAsync<Metadatas>("get", "profilermetadata", "online");
            if (SavedToken?.Value != null)
            {
                var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(SavedToken.Value);
                if (DateTime.UtcNow >= claimObject.ValidTo)
                {
                    MarkUserAsLoggedOut();
                    return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
                }

                http.DefaultRequestHeaders.Authorization = new AuthenticationHeaderValue("bearer", SavedToken.Value);
                var authenticatedUser = new ClaimsPrincipal(new ClaimsIdentity(claimObject.Claims, "serverauth"));
                return new AuthenticationState(authenticatedUser);
            }
            return new AuthenticationState(new ClaimsPrincipal(new ClaimsIdentity()));
        }

        public void MarkUserAsAuthenticated(string token)
        {
            var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(token);
            var authenticatedUser = new ClaimsPrincipal(new ClaimsIdentity(claimObject.Claims, "serverauth"));
            var authState = Task.FromResult(new AuthenticationState(authenticatedUser));
            NotifyAuthenticationStateChanged(authState);
        }

        public void MarkUserAsLoggedOut()
        {
            var anonymousUser = new ClaimsPrincipal(new ClaimsIdentity());
            var authState = Task.FromResult(new AuthenticationState(anonymousUser));
            NotifyAuthenticationStateChanged(authState);
        }

        public string GetAuthenticatedUserData(string token, string dataRequested)
        {
            var claimObject = new JsonWebTokenHandler().ReadJsonWebToken(token);
            return claimObject.Claims.FirstOrDefault(x => x.Type == dataRequested)!.Value;
        }
    }
}
