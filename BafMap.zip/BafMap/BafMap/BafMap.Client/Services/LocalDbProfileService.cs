﻿using Microsoft.JSInterop;
using BafMap.Client.DTOs;
using System.Text.Json;

namespace BafMap.Client.Services
{
    public class LocalDbProfileService(IJSRuntime jSRuntime) : ILocalDbProfileService
    {
        private readonly IJSRuntime js = jSRuntime;
        private const string ProfileStore = "profiles";
        private const string ChangesStore = "profilechanges";
        private const string MetaStore = "profilermetadata";

        public async Task SaveLocalChangesAsync(ProfileDto data, bool pending = true)
        {
            await js.InvokeVoidAsync("put", ProfileStore, JsonSerializer.Serialize(data));
            if (pending)
                await js.InvokeVoidAsync("put", ChangesStore, JsonSerializer.Serialize(data));
        }

        public async Task DeleteAsync(string id) => await js.InvokeVoidAsync("deleteKey", ProfileStore, id).AsTask();

        public async Task<List<ProfileDto>?> GetAllAsync()
        {
            var data = await js.InvokeAsync<object[]>("getAll", ProfileStore);
            var json = JsonSerializer.Serialize(data);

            return JsonSerializer.Deserialize<List<ProfileDto>>(json) ?? [];
        }

        public async Task<ProfileDto?> GetAsync(string id)
        {
            var obj = await js.InvokeAsync<object>("get", ProfileStore, id);
            if (obj == null) return null;
            var json = JsonSerializer.Serialize(obj);

            return JsonSerializer.Deserialize<ProfileDto>(json) ?? null;
        }

        public async Task<List<ProfileDto>?> GetLocalPendingChangesAsync()
        {
            var arr = await js.InvokeAsync<object[]>("getAll", ChangesStore);
            var json = JsonSerializer.Serialize(arr);

            return JsonSerializer.Deserialize<List<ProfileDto>>(json) ?? [];
        }

        public async Task ApplyServerPullChangesAsync(string id) => await js.InvokeVoidAsync("deleteKey", ChangesStore, id).AsTask();

        public async Task<string?> GetLastSyncTokenAsync()
        {
            var obj = await js.InvokeAsync<object>("get", MetaStore, "lastSyncToken");
            if (obj == null) return null;
            using var doc = JsonDocument.Parse(JsonSerializer.Serialize(obj));
            if (doc.RootElement.TryGetProperty("Value", out var val)) 
                return val.GetString();
            return null;
        }

        public async Task SetLastSyncTokenAsync(string token)
        {
            var metadata = new { Key = "lastSyncToken", Value = token };
            await js.InvokeVoidAsync("put", MetaStore, metadata);
        }
    }
}
