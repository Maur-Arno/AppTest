﻿using BafMap.Client.DTOs;

namespace BafMap.Client.Services
{
    public interface IAuthService
    {
        Task<string> LoginAsync(LoginDto login);
        void Logout();
    }
}
