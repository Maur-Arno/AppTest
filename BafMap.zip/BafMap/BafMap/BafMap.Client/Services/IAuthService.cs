﻿namespace BafMap.Client.AuthenticationStateProviders
{
    public interface IAuthService
    {
        Task ShowHidePassword(string id_password);
        Task Logout();
    }
}
