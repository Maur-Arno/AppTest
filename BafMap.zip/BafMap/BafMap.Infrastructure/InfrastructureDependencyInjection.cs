﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using BafMap.Infrastructure.Persistence;
using BafMap.Infrastructure.Repositories;
using Microsoft.AspNetCore.Identity;
using Microsoft.Data.SqlClient;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.DependencyInjection;
using System.Data;

namespace BafMap.Infrastructure
{
    public static class InfrastructureDependencyInjection
    {
        public static IServiceCollection AddInfrastructureDI(this IServiceCollection services, string? connectionString)
        {
            // Enregistrement de la connecion Dapper pour les lectures
            services.AddTransient<IDbConnection>(_ => new SqlConnection(connectionString));

            // Enregistrement de la connecion EF Core pour les écritures
            services.AddDbContextPool<BafMapContext>(options => options.UseSqlServer(connectionString,
                                                                                        sqlServerOptionsAction: sqlOptions =>
                                                                                        {
                                                                                            sqlOptions.EnableRetryOnFailure();
                                                                                            sqlOptions.UseNetTopologySuite();
                                                                                        }));
            // Les token providers sont automatiquement enregistrés à partir de .net 8!
            services.AddIdentityCore<User>(options =>
            {
                options.User.AllowedUserNameCharacters = "abcdefghijklmnopqrstuvwxyzéèêàâç'ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789-._@+/ ";
                options.User.RequireUniqueEmail = false;
                options.Password.RequiredUniqueChars = 4;
                options.Password.RequireDigit = true;
                options.Password.RequiredLength = 8;
                options.Password.RequireNonAlphanumeric = true;
                options.Password.RequireUppercase = true;
                options.Password.RequireLowercase = true;
                options.Lockout.MaxFailedAccessAttempts = 3;
                options.Lockout.DefaultLockoutTimeSpan = TimeSpan.FromMinutes(20);
                options.Lockout.AllowedForNewUsers = true;
                options.SignIn.RequireConfirmedEmail = false;
                options.SignIn.RequireConfirmedPhoneNumber = true;
            })
            .AddRoles<Role>()
            .AddEntityFrameworkStores<BafMapContext>()
            .AddDefaultTokenProviders()
            .AddPasswordlessLoginTotpTokenProvider(); // Add the custom token provider.

            // Enregistrement des services spécifiques
            services.AddScoped<IReferenceGenerator, ReferenceGenerator>();
            services.AddScoped<ILocationValidationRepository, LocationValidationRepository>();
            services.AddScoped<ILocationReadRepository, LocationReadRepository>();
            services.AddScoped<IUnitOfWork, UnitOfWork>();

            return services;
        }
    }
}
