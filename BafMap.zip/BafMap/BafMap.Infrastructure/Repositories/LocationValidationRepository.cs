﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using BafMap.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;
using NetTopologySuite.Geometries;

namespace BafMap.Infrastructure.Repositories
{
    public class LocationValidationRepository(ILoggerFactory factory, BafMapContext context) : ILocationValidationRepository
    {
        private readonly ILogger _logger = factory.CreateLogger("LocationValidationRepository");
        private readonly BafMapContext _context = context;

        public async Task<bool> RegisterReference(string city, string quarter, char category, uint referenceCode)
        {
            try
            {
                await _context.ReferenceCounters.AddAsync(new ReferenceCounter(city, quarter, category, referenceCode));
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        public async Task<List<Address>?> AddressesNearByAsync(double Longitude, double Latitude)
        {
            // SRID 4326 correspond au système GPS WGS84.
            var point = new Point(Longitude, Latitude) { SRID = 4326 };
            try
            {
                return await _context.Addresses.Where(ad => ad.Position.Distance(point) <= 10).ToListAsync();
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return null;
            }
        }

        public async Task<bool> AddAddressAsync(Address address)
        {
            try
            {
                await _context.Addresses.AddAsync(address);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        public async Task<bool> AddTempAddressAsync(LocationRequest tempAddress)
        {
            try
            {
                await _context.LocationRequests.AddAsync(tempAddress);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        public bool UpdateAddress(Address address)
        {
            try
            {
                _context.Addresses.Update(address);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        public bool DeleteAddress(Address address)
        {
            try
            {
                _context.Addresses.Remove(address);
                return true;
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return false;
            }
        }

        public async Task<List<Address>?> GetAddressesAsync(string city, string quarter)
        {
            return await _context.Addresses?.Where(ad => ad.City == city && ad.Quarter == quarter)?.ToListAsync()!;
        }
    }
}
