﻿using BafMap.Domain.Entities;
using BafMap.Domain.Ports;
using Dapper;
using Microsoft.Extensions.Logging;
using System.Data;

namespace BafMap.Infrastructure.Repositories
{
    public class LocationReadRepository(ILoggerFactory factory, IDbConnection connection) : ILocationReadRepository
    {
        private readonly ILogger _logger = factory.CreateLogger("LocationReadRepository");
        private readonly IDbConnection _connection = connection;

        public async Task<bool> ExistsAddressReferenceAsync(string reference)
        {
            const string sql = """
                SELECT
                    TOP 1 1
                FROM Addresses
                WHERE reference=@reference
                """;
            var result = await _connection.ExecuteScalarAsync<int?>(sql, new { reference });
            return result.HasValue;
        }

        public async Task<bool> ExistsNearByAsync(string Name, LocationType Category, double Longitude, double Latitude, double RadiusInMeters, CancellationToken cancellationToken)
        {
            const string sql = "DECLARE @Position geography = geograhy::Point(@Latitude, @Longitude, 4326); SELECT TOP 1 1 FROM Addresses WHERE Position.STDistance(@Position) <= @RadiusInMeters AND LocalName = @Name AND Category = @Category";
            var result = await _connection.ExecuteScalarAsync<int?>(sql, new { Name, Category, RadiusInMeters });
            return result.HasValue;
        }

        public async Task<Address?> GetAddressByReferenceAsync(string reference)
        {
            const string sql = """
                SELECT
                    reference,
                    name,
                    quarter,
                    category,
                    googlePlusCode,
                    description,
                    photoUrl
                FROM Addresses
                WHERE reference=@reference
                """;

            return await _connection.QueryFirstOrDefaultAsync<Address>(sql, new { reference });
        }

        public async Task<List<LocationRequest>?> GetPendingLocationsAsync(string city)
        {
            const string sql = """
                SELECT
                    reference,
                    name,
                    quarter,
                    category,
                    googlePlusCode,
                    description,
                    photoUrl
                FROM LocationRequests
                WHERE Status=0 AND City=@city
                """;

            return await _connection.QueryFirstOrDefaultAsync<List<LocationRequest>>(sql, new { city });
        }
    }
}
