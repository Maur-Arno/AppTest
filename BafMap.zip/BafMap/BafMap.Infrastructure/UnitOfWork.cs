﻿using BafMap.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore.Storage;

namespace BafMap.Infrastructure
{
    public class UnitOfWork(BafMapContext context) : IUnitOfWork
    {
        private readonly BafMapContext _context = context;

        public Task<IDbContextTransaction> BeginTransactionAsync(CancellationToken cancellationToken)
         => _context.Database.BeginTransactionAsync(cancellationToken);

        public Task<int> SaveChangesAsync(CancellationToken cancellationToken = default)
         => _context.SaveChangesAsync(cancellationToken);
    }
}
