﻿using BafMap.Domain.Entities;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;

namespace BafMap.Infrastructure.Persistence
{
    public class BafMapContext(DbContextOptions options) : IdentityDbContext<User, Role, Guid, IdentityUserClaim<Guid>,
                    UserRole, IdentityUserLogin<Guid>, IdentityRoleClaim<Guid>, IdentityUserToken<Guid>>(options)
    {
        public DbSet<LocationRequest> LocationRequests => Set<LocationRequest>();
        public DbSet<Address> Addresses => Set<Address>();
        public DbSet<ReferenceCounter> ReferenceCounters => Set<ReferenceCounter>();
        public new DbSet<User> Users => Set<User>();
        public new DbSet<Role> Roles => Set<Role>();
        public new DbSet<UserRole> UserRoles => Set<UserRole>();

        protected override void OnModelCreating(ModelBuilder builder)
        {
            builder.Entity<IdentityUserLogin<Guid>>().HasKey(x => x.UserId);
            builder.Entity<IdentityUserToken<Guid>>().HasKey(x => x.UserId);
            builder.Entity<IdentityPasskeyData>().HasNoKey();
            builder.Entity<IdentityUserPasskey<Guid>>().HasKey(x => x.UserId);
            builder.Entity<IdentityUserPasskey<Guid>>().Ignore(x => x.Data);

            builder.Entity<Address>(entity =>
            {
                entity.ToTable("Addresses");
                entity.HasKey(x => x.Id);
                entity.Property(x => x.Position)
                      .HasColumnType("geography");
                entity.Property(x => x.Reference)
                      .HasMaxLength(20);
                entity.HasIndex(x => x.Reference).IsUnique();
            });

            builder.Entity<LocationRequest>(entity =>
            {
                entity.ToTable("LocationRequests");
                entity.HasKey(x => x.Id);
                entity.Property(x => x.Position)
                      .HasColumnType("geography");
                entity.Property(x => x.Reference)
                      .HasMaxLength(20);
                entity.HasIndex(x => x.Reference).IsUnique();
            });

            builder.Entity<LocationRequest>(entity => entity.HasKey(x => x.Id));

            builder.Entity<User>(c =>
            {
                c.ToTable("Users");
                c.HasMany(e => e.Claims)
                    .WithOne()
                    .HasForeignKey(uc => uc.UserId)
                    .IsRequired();

                c.HasMany(e => e.Logins)
                    .WithOne()
                    .HasForeignKey(ul => ul.UserId)
                    .IsRequired();

                c.HasMany(e => e.Tokens)
                    .WithOne()
                    .HasForeignKey(ut => ut.UserId)
                    .IsRequired();

                c.HasMany(e => e.Roles)
                    .WithOne(e => e.User)
                .HasForeignKey(ur => ur.UserId)
                    .OnDelete(DeleteBehavior.ClientCascade)
                    .IsRequired();
            });

            builder.Entity<Role>(b =>
            {
                b.ToTable("Roles");
                b.Property(u => u.Id).HasDefaultValueSql("newsequentialid()");

                b.HasData(new Role { Id = new Guid("b3cc034e-a970-4740-a9c3-4e88000d805a"), Key = "shield-user", Name = "Admin", NormalizedName = "ADMIN", ConcurrencyStamp = "b28ba02d-1690-4885-9693-b0088cd6a48e" });
                b.HasData(new Role { Id = new Guid("b28b2da0-1690-4885-9693-b0cd0886a48e"), Key = "landmark", Name = "MunicipalAgent", NormalizedName = "MUNICIPALAGENT", ConcurrencyStamp = "2843c801-6abc-46a6-9433-96c1729e58ff" });
                b.HasData(new Role { Id = new Guid("2880c431-6abc-64a6-9343-96c172e589ff"), Key = "user", Name = "Citizen", NormalizedName = "CITIZEN", ConcurrencyStamp = "f5844f2e-267f-4ac7-af5b-4a5c62d23e91" });

                b.HasMany(e => e.Users)
                    .WithOne(e => e.Role)
                    .HasForeignKey(ur => ur.RoleId)
                    .OnDelete(DeleteBehavior.Cascade)
                    .IsRequired();

                // Each Role can have many RoleClaims
                b.HasMany(e => e.Claims)
                    .WithOne()
                    .HasForeignKey(uc => uc.RoleId)
                    .IsRequired();
            });

            builder.Entity<UserRole>(r =>
            {
                r.ToTable("UserRoles");
                r.HasKey(ur => new { ur.UserId, ur.RoleId });
            });

            builder.Entity<Address>()
                    .HasOne(m => m.User)
                    .WithMany(m => m.Addresses)
                    .HasForeignKey(m => m.UserId)
                    .OnDelete(DeleteBehavior.SetNull);
        }
    }
}
