﻿using BafMap.Domain.Ports;
using BafMap.Infrastructure.Persistence;
using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Logging;

namespace BafMap.Infrastructure
{
    public class ReferenceGenerator(ILoggerFactory factory, BafMapContext context) : IReferenceGenerator
    {
        private readonly ILogger _logger = factory.CreateLogger("ReferenceGenerator");
        private readonly BafMapContext _context = context;
        public async Task<string> GenerateAsync(string cityCode, string quarterCode, string category, CancellationToken cancellationToken)
        {
            try
            {
                var connection = _context.Database.GetDbConnection();
                await connection.OpenAsync(cancellationToken);

                using var command = connection.CreateCommand();
                // Utilisation de la séquence SQL Server qui garantit l'inicité meme avec plusieurs utilisateurs.
                command.CommandText = "SELECT NEXT VALUE FOR dbo.LocationsReferenceSequence";
                var number = (long?)await command.ExecuteScalarAsync(cancellationToken);
                return $"{cityCode}-{quarterCode}-{category}-{number:000000}";
            }
            catch (Exception ex)
            {
                _logger.LogError(ex, ex.Message);
                return string.Empty;
            }            
        }        
    }
}
