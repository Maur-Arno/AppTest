﻿namespace BafMap.Infrastructure.Exceptions
{
    public class DuplicateLocationException : Exception
    {
        public DuplicateLocationException(string Message) : base(Message)
        {            
        }
    }
}
