﻿namespace BafMap.Infrastructure.Exceptions
{
    public class DuplicateReferenceException : Exception
    {
        public DuplicateReferenceException(string Message) : base(Message)
        {            
        }
    }
}
