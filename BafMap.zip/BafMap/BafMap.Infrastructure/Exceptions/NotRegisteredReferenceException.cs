﻿namespace BafMap.Infrastructure.Exceptions
{
    public class NotRegisteredReferenceException : Exception
    {
        public NotRegisteredReferenceException(string Message) : base(Message)
        {            
        }
    }
}
